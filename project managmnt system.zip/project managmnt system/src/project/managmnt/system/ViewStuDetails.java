
package project.managmnt.system;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.sql.*;
import net.proteanit.sql.DbUtils;

public class ViewStuDetails extends JFrame implements ActionListener{
    JTable table;
    JPanel panel;
    JButton b1;
    ViewStuDetails(){
        setTitle("Project Management System");
        setPreferredSize(new Dimension(1000,650));
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
     
        panel = new JPanel();
	panel.setBackground(Color.pink);
	setContentPane(panel);
        panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 3)));
			//TitledBorder.LEADING, TitledBorder.TOP, null, Color.white));
        panel.setLayout(null);
        
        JPanel panel1 = new JPanel();
	panel1.setBackground(Color.white);
	//panel1.setForeground(Color.black);
        panel1.setBounds(8, 16, 970, 30);
        panel.add(panel1);
        
        JLabel l1 = new JLabel("Student   Details");
        l1.setForeground(Color.black);
        l1.setBounds(430,5,140,25);
        l1.setFont(new Font("Times new roman", Font.BOLD, 17));
        panel1.add(l1);
        
        JLabel l2 = new JLabel("Name");
        l2.setForeground(Color.black);
        l2.setBounds(20,65,100,25);
        l2.setFont(new Font("Times new roman", Font.BOLD, 17));
        panel.add(l2);
        
        JLabel l3 = new JLabel("Branch");
        l3.setForeground(Color.black);
        l3.setBounds(120,65,100,25);
        l3.setFont(new Font("Times new roman", Font.BOLD, 17));
        panel.add(l3);
        JLabel l4 = new JLabel("Year/sem");
        l4.setForeground(Color.black);
        l4.setBounds(205,65,100,25);
        l4.setFont(new Font("Times new roman", Font.BOLD, 17));
        panel.add(l4);
        
        JLabel l5 = new JLabel("Phone no");
        l5.setForeground(Color.black);
        l5.setBounds(300,65,100,25);
        l5.setFont(new Font("Times new roman", Font.BOLD, 17));
        panel.add(l5);
        
        JLabel l6 = new JLabel("Email");
        l6.setForeground(Color.black);
        l6.setBounds(400,65,100,25);
        l6.setFont(new Font("Times new roman", Font.BOLD, 17));
        panel.add(l6);
        
        JLabel l7 = new JLabel("DOB");
        l7.setForeground(Color.black);
        l7.setBounds(495,65,100,25);
        l7.setFont(new Font("Times new roman", Font.BOLD, 17));
        panel.add(l7);
        
        JLabel l8 = new JLabel("Father name");
        l8.setForeground(Color.black);
        l8.setBounds(590,65,120,25);
        l8.setFont(new Font("Times new roman", Font.BOLD, 15));
        panel.add(l8);
        
        JLabel l9 = new JLabel("Mother name");
        l9.setForeground(Color.black);
        l9.setBounds(680,65,120,25);
        l9.setFont(new Font("Times new roman", Font.BOLD, 15));
        panel.add(l9);
        
        JLabel l10 = new JLabel("Gender");
        l10.setForeground(Color.black);
        l10.setBounds(780,65,90,25);
        l10.setFont(new Font("Times new roman", Font.BOLD, 17));
        panel.add(l10);
        
        JLabel l11 = new JLabel("Address");
        l11.setForeground(Color.black);
        l11.setBounds(860,65,140,25);
        l11.setFont(new Font("Times new roman", Font.BOLD,17));
        panel.add(l11);
        
        
        
        
        
        
        b1 = new JButton("Back");
        b1.setBackground(Color.black);
        b1.setForeground(Color.white);
        b1.setBounds(830,560,100,30);
        b1.addActionListener(this);
        panel.add(b1);
        
                
                table = new JTable();
		table.setBounds(20,90, 940, 490);
		panel.add(table);
                
                try{
                    Conn c = new Conn();
                        String displaystuinfosql = "select * from stuinfo";
                        ResultSet rs = c.s.executeQuery(displaystuinfosql);
                        table.setModel(DbUtils.resultSetToTableModel(rs));
                }
                catch(Exception e1){
                        e1.printStackTrace();
                }
    }
    
    public static void main(String args[]){
        EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {ViewStuDetails vsd = new  ViewStuDetails();
                                     vsd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
    }
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b1){
                setVisible(false);
		TeacherZone tz = new TeacherZone("");
		tz.setVisible(true);
         }  
    }
}















/*package travel.management.system;


import java.awt.BorderLayout;
import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import java.sql.*;	
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class ViewCustomers extends JFrame {
	Connection conn = null;
	private JPanel contentPane;
	private JTable table;
	private JLabel lblAvailability;
	private JLabel lblCleanStatus;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblRoomNumber;
	private JLabel lblId;

	/**
	 * Launch the application.

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewCustomers frame = new ViewCustomers();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

        
	public ViewCustomers() throws SQLException {
		//conn = Javaconnect.getDBConnection();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 50, 900, 680);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
                
                ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("travel/management/system/icons/viewall.jpg"));
                Image i3 = i1.getImage().getScaledInstance(626, 201,Image.SCALE_DEFAULT);
                ImageIcon i2 = new ImageIcon(i3);
                JLabel l1 = new JLabel(i2);
                l1.setBounds(0,450,626,201);
                add(l1);
                
                ImageIcon i4  = new ImageIcon(ClassLoader.getSystemResource("travel/management/system/icons/viewall.jpg"));
                Image i5 = i4.getImage().getScaledInstance(626, 201,Image.SCALE_DEFAULT);
                ImageIcon i6 = new ImageIcon(i5);
                JLabel l2 = new JLabel(i6);
                l2.setBounds(615,450,626,201);
                add(l2);
                
		
		table = new JTable();
		table.setBounds(0, 40, 900, 350);
		contentPane.add(table);
                
                try{
                    Conn c = new Conn();
                        String displayCustomersql = "select * from customer";
                        ResultSet rs = c.s.executeQuery(displayCustomersql);
                        table.setModel(DbUtils.resultSetToTableModel(rs));
                }
                catch(Exception e1){
                        e1.printStackTrace();
                }
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton.setBounds(390, 400, 120, 30);
                btnNewButton.setBackground(Color.BLACK);
                btnNewButton.setForeground(Color.WHITE);
		contentPane.add(btnNewButton);
		
		lblAvailability = new JLabel("Username");
		lblAvailability.setBounds(10, 15, 69, 14);
		contentPane.add(lblAvailability);
		
		lblCleanStatus = new JLabel("Id Type");
		lblCleanStatus.setBounds(110, 15, 76, 14);
		contentPane.add(lblCleanStatus);
		
		lblNewLabel = new JLabel("Number");
		lblNewLabel.setBounds(220, 15, 46, 14);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(320, 15, 76, 14);
		contentPane.add(lblNewLabel_1);

		
		lblId = new JLabel("Gender");
		lblId.setBounds(420, 15, 90, 14);
		contentPane.add(lblId);
                
                JLabel l3 = new JLabel("Country");
		l3.setBounds(520, 15, 90, 14);
		contentPane.add(l3);
                
                JLabel l4 = new JLabel("Address");
		l4.setBounds(620, 15, 90, 14);
		contentPane.add(l4);
                
                JLabel l5 = new JLabel("Phone");
		l5.setBounds(720, 15, 90, 14);
		contentPane.add(l5);
                
                JLabel l6 = new JLabel("Email");
		l6.setBounds(820, 15, 90, 14);
		contentPane.add(l6);
                
                getContentPane().setBackground(Color.WHITE);
	}

}*/