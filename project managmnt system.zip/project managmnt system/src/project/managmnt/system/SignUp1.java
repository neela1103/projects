
package project.managmnt.system;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
public class SignUp1 extends JFrame implements ActionListener {
   private JPanel panel;
    private JButton b1,b2,b3;
   // private JTextField textField;
    private JTextField t2;
    private JTextField t3;
   // private JTextField t4;
    private JPasswordField t4;
  
     private JTextField t5;
     private JComboBox comboBox;
     
      public static void main(String args[]){
        new SignUp1().setVisible(true);
    }
            SignUp1(){
            setTitle("Signup");
            setPreferredSize(new Dimension(350,550));
            pack();
            setLocationRelativeTo(null);
            setResizable(false);
            panel = new JPanel();
            panel.setBackground(Color.white);
            setContentPane(panel);
            panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 5)));
        	//TitledBorder.LEADING, TitledBorder.TOP, null, Color.black)); 
            panel.setLayout(null);
              
            JLabel l1 = new JLabel("SIGN UP HERE");
            l1.setBounds(60,12,240,25);
            l1.setFont(new Font("Times New Roman", Font.BOLD, 28));
             panel.add(l1);
           
            JPanel panel2 = new JPanel();
            panel2.setBackground(new Color(64,224,208));  //signup panel
            panel2.setBounds(5,10,325,30);
            panel2.setLayout(null);
            panel.add(panel2);
            
            JPanel panel3 = new JPanel();
            panel3.setBackground(new Color(127,255,212));      //info panel
            panel3.setBounds(15,68,305,400);
            panel3.setLayout(null);
            panel.add(panel3);
            
            JLabel l2 = new JLabel("Your Name");
            l2.setBounds(95,10,300,25);
            l2.setFont(new Font("Times New Roman", Font.BOLD, 18));
            panel3.add(l2);
                
            t2 = new JTextField();
            t2.setBounds(40,40,220,25);
            t2.setFont(new Font("Times New Roman", Font.BOLD, 18));
            panel3.add(t2);
            
            JLabel l3 = new JLabel("Username");
            l3.setBounds(95,70,300,25);
            l3.setFont(new Font("Times New Roman", Font.BOLD, 18));
            panel3.add(l3);
                
            t3 = new JTextField();
            t3.setBounds(40,100,220,25);
            t3.setFont(new Font("Times New Roman", Font.BOLD, 18));
            panel3.add(t3);
           
            JLabel l4 = new JLabel("Password");
            l4.setBounds(95, 130, 300, 25);
            l4.setFont(new Font("Times New Roman", Font.BOLD, 18));
            panel3.add(l4);
        
            t4 = new JPasswordField();
            t4.setBounds(40,160,220,25);
            t4.setFont(new Font("Times New Roman", Font.BOLD, 18));
            panel3.add(t4);   
            
            JLabel l5 = new JLabel("Security Ques");
                l5.setFont(new Font("Times New Roman", Font.BOLD, 18));
                l5.setBounds(95, 190, 300, 25);
                panel3.add(l5);
                comboBox = new JComboBox();
	        comboBox.setModel(new DefaultComboBoxModel(new String[] { "Your NickName?", "Your Lucky Number?",
			"Your child SuperHero?", "Your childhood Name ?" }));
	        comboBox.setBounds(55, 220, 200, 25);
	        panel3.add(comboBox);
                
                JLabel l6 = new JLabel("Answer");
                l6.setForeground(Color.DARK_GRAY);
                l6.setFont(new Font("Times New Roman", Font.BOLD, 18));
                l6.setBounds(105, 250, 200, 25);
                panel3.add(l6);

                t5 = new JTextField();
                t5.setBounds(40, 280,220,25);
                t5.setFont(new Font("Times New Roman", Font.BOLD, 18));
                panel3.add(t5);
                
                b1 = new JButton("Create");
                b1.addActionListener(this);
                b1.setFont(new Font("Tahoma", Font.BOLD, 13));
                b1.setBounds(35, 330, 100, 30);
                b1.setBackground(new Color(64,224,208));
                b1.setForeground(Color.BLACK);
                
                panel3.add(b1);

                b2 = new JButton("Back");
                b2.addActionListener(this);
                b2.setFont(new Font("Tahoma", Font.BOLD, 13));
                b2.setBounds(165, 330, 100, 30);
                b2.setBackground(new Color(64,224,208));
                b2.setForeground(Color.black);
                panel3.add(b2);
                
            }
            
   
     public void actionPerformed(ActionEvent ae){
        try{
            Conn con = new Conn();
            
            if(ae.getSource() == b1){
                String sql = "insert into stusignup(name, username, password, question, answer) values(?, ?, ?, ?, ?)";
		PreparedStatement st = con.c.prepareStatement(sql);

		st.setString(1, t2.getText());
                st.setString(2, t3.getText());
		st.setString(3, t4.getText());
		st.setString(4, (String) comboBox.getSelectedItem());
		st.setString(5, t5.getText());

		int i = st.executeUpdate();
		if (i > 0){
                    JOptionPane.showMessageDialog(null, "Account Created Successfully ");
                    this.setVisible(false);
                    new login().setVisible(true);
                }

                t2.setText("");
                t3.setText("");
		t4.setText("");
		t5.setText("");
            }
            if(ae.getSource() == b2){
                this.setVisible(false);
                new login().setVisible(true);
			
            }
        }catch(Exception e){
                System.out.println(e);
        }
    }
}

