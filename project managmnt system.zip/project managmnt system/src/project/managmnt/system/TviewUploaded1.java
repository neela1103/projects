
package project.managmnt.system;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.net.*;

public class TviewUploaded1 extends JFrame {
            JPanel panel;
            static ServerSocket skt;
            static Socket s;
             static File filetosend;
            
            TviewUploaded1()throws Exception{
            setTitle("Project mngmnt system");
            setPreferredSize(new Dimension(320,450));
            pack();
            setLocationRelativeTo(null);
            setResizable(false);
            panel = new JPanel();
            panel.setBackground(Color.white);
            setContentPane(panel);
            panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
        	//TitledBorder.LEADING, TitledBorder.TOP, null, Color.black)); 
            panel.setLayout(null);

            JPanel panel2 = new JPanel();
            panel2.setBackground(Color.pink);
            panel2.setBounds(6,6,293,50);
            panel2.setLayout(null);
            panel2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
            panel.add(panel2);
            
            JLabel l1 = new JLabel("View Uploaded Assigment");                            
            l1.setBounds(28,5,230,44);
            l1.setFont(new Font("Times new roman", Font.BOLD, 20));
            panel2.add(l1);
            
            JPanel panel3 = new JPanel();
            panel3.setBackground(Color.pink);
            panel3.setBounds(40,65,229,330);
            panel3.setLayout(null);
            panel3.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
            panel.add(panel3);
    
    }
    public static void main(String args[]) throws Exception{
        
        ServerSocket skt = new ServerSocket(9004);
        Socket s = skt.accept();
         try {
                                FileInputStream fileInputStream = new FileInputStream(filetosend.getAbsolutePath());
                             
                       
                                DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());
                       
                                String fileName = filetosend.getName();
                                byte[] fileNameBytes = fileName.getBytes();
                       
                                byte[] fileContentBytes = new byte[(int) filetosend.length()];
                                fileInputStream.read(fileContentBytes);
                       
                                dataOutputStream.writeInt(fileNameBytes.length);
                                dataOutputStream.write(fileNameBytes);
                       
                                dataOutputStream.writeInt(fileContentBytes.length);
                                dataOutputStream.write(fileContentBytes);
                       
                            }catch (Exception e){
                                e.printStackTrace();
                            }
        
        
    TviewUploaded1 vu = new TviewUploaded1();
        vu.setVisible(true);
    }
}
