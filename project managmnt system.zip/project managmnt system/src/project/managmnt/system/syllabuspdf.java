
package project.managmnt.system;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

    public class syllabuspdf extends JFrame implements ActionListener{
        JPanel panel;
        JButton b1,b2;
        syllabuspdf(){
        setTitle("View Syllabus");
                setPreferredSize(new Dimension(400,300));
                pack();
                setLocationRelativeTo(null);
                setResizable(false);
                
                panel = new JPanel();
                panel.setBackground(new Color(176,224,230));                          //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2), "View Syllabus",
                TitledBorder.LEADING, TitledBorder.TOP, null, Color.black));
                
                JPanel panel1 = new JPanel();
                panel1.setBackground(new Color(218,112,214));                            //panel for time table
                panel1.setLayout(null);
                setContentPane(panel);
                panel1.setBounds(2,20,381,39);
                panel1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel1);
                
                JLabel l1 = new JLabel("Download From here");                              //label for student i card
                l1.setBounds(100,5,190,34);
                l1.setFont(new Font("Times new roman", Font.BOLD, 18));
                panel1.add(l1);
                
                b1 = new JButton("View pdf");
                b1.setFont(new Font("Times new roman", Font.BOLD, 24));
                b1.setBounds(95, 90, 190, 125);              
                b1.setBackground(new Color(218,112,214));
                b1.setForeground(Color.black);
                b1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                b1.addActionListener(this);
                panel.add(b1);
                
                b2 = new JButton("Back");
                b2.setFont(new Font("Times new roman", Font.BOLD, 16));
                b2.setBounds(155, 226, 60, 25);              
                b2.setBackground(new Color(218,112,214));
                b2.setForeground(Color.black);
                b2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 3)));
                b2.addActionListener(this);
                panel.add(b2);
                
                b1.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent a){
                    try{
                        Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler "+"C:/Users/neela/OneDrive/Pictures/neelam/syllabus.pdf");
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, "check file details");
                    }
                }
                }
                );
                
        }
    
            public static void main(String args[]){

            new syllabuspdf().setVisible(true);
            }

   
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == b2){
                setVisible(false);
		ProjectManagmntSystem sm = new ProjectManagmntSystem("");
		sm.setVisible(true);
            } 
    }
}






















/*package project.managmnt.system;

import com.sun.pdfview.PDFFile;
import com.sun.pdfview.PDFPage;
import com.sun.pdfview.PagePanel;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import javax.swing.*;

/**
 * An example of using the PagePanel class to show PDFs. For more advanced
 * usage including navigation and zooming, look at the com.sun.pdfview.PDFViewer class.
 *
 * @author joshua.marinacci@sun.com
 

public class syllabuspdf {

    public static void setup() throws IOException {
    
        //set up the frame and panel
        JFrame frame = new JFrame("PDF Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        PagePanel panel = new PagePanel();
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);

        //load a pdf from a byte buffer
        File file = new File("test.pdf");
        RandomAccessFile raf = new RandomAccessFile(file, "r");
        FileChannel channel = raf.getChannel();
        ByteBuffer buf = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
        PDFFile pdffile = new PDFFile(buf);

        // show the first page
        PDFPage page = pdffile.getPage(0);
        panel.showPage(page);
        
    }

    public static void main(final String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    syllabuspdf.setup();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
}
*/