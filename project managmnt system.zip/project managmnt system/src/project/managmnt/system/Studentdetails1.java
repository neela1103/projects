package project.managmnt.system;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.sql.*;
import java.io.File;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Studentdetails1 extends JFrame implements ActionListener{
    JPanel panel;
    JButton b1,b2,b3,b4,b5,b6;
    private JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,tf1,tf3,tf4,tf5,tf7,tf8,tf9;
    private JComboBox comboBox1,comboBox2;//comboBox3,comboBox4,comboBox5;
     JRadioButton r1,r2;
     private JTextArea textarea,textarea1;
     JFrame tf6;
     JLabel l2,l4;
     String name;
     
    Studentdetails1(String name){
    this.name= name;
        setTitle("Project Management System");
                setPreferredSize(new Dimension(700,650));
                pack();
                setLocationRelativeTo(null);
                setResizable(false);
                
                panel = new JPanel();
                panel.setBackground(new Color(255,192,203));                            //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2), "Student Details",
                TitledBorder.LEADING, TitledBorder.TOP, null, Color.black));
                 
                 l2 = new JLabel();
                 l2.setBounds(540,70,120,130);
                 l2.setBackground(new Color(216,191,216));                         //label for student image
                 l2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 3)));
                 add(l2);
                 
                JPanel panel1 = new JPanel();
                panel1.setBackground(new Color(230,230,250));
                panel1.setBounds(8,20,670,220);
                panel1.setLayout(null);                                                  //uper partition
                panel1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel1);
                
                 l4 = new JLabel();    //540,70,120,130
                 l4.setBounds(540,320,120,130);
                 l4.setBackground(new Color(216,191,216));                         //lower label for student image
                 l4.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 3)));
                 add(l4); 
                 
                JPanel panel2 = new JPanel();
                panel2.setBackground(new Color(230,230,250));
                panel2.setBounds(8,255,670,340);
                panel2.setLayout(null);
                panel2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));     //lower partition
                panel.add(panel2);
                
                JPanel panel3 = new JPanel();
                panel3.setBackground(new Color(216,191,216));
                panel3.setBounds(1,5,668,25);                                     //panel for student id card
                panel3.setLayout(null);
                panel3.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                panel1.add(panel3);
                
                JLabel l1 = new JLabel("Student Id card");                              //label for student i card
                l1.setBounds(250,1,160,24);
                l1.setFont(new Font("Times new roman", Font.BOLD, 18));
                panel3.add(l1);
                
                JPanel panel4 = new JPanel();
                panel4.setBackground(new Color(216,191,216));                     //panel for uper partition student details 
                panel4.setBounds(15,34,500,180);
                panel4.setLayout(null);
                panel4.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                panel1.add(panel4);
                
                JPanel panel5 = new JPanel();
                panel5.setBackground(new Color(216,191,216));
                panel5.setBounds(1,6,668,30);                                     //panel for student information
                panel5.setLayout(null);
                panel5.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                panel2.add(panel5);
                
                JLabel l3 = new JLabel("Student Information");                            
                l3.setBounds(230,1,230,24);
                l3.setFont(new Font("Times new roman", Font.BOLD, 22));
                panel5.add(l3);
                
                JPanel panel6 = new JPanel();
                panel6.setBackground(new Color(216,191,216));                     //panel for Lower partition student information
                panel6.setBounds(15,40,500,293);
                panel6.setLayout(null);
                panel6.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                panel2.add(panel6);
                
                JLabel l5 = new JLabel("Name");                            
                l5.setBounds(5,5,100,25);
                l5.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l5);
                
                JLabel l6 = new JLabel("Branch");                            
                l6.setBounds(5,30,130,25);
                l6.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l6);
                
                JLabel l7 = new JLabel("Year/sem");                            
                l7.setBounds(5,55,170,25);
                l7.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l7);
                
                JLabel l8 = new JLabel("Phone no.");                            
                l8.setBounds(5,80,170,25);
                l8.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l8);
                
                JLabel l9 = new JLabel("E-mail");                            
                l9.setBounds(5,105,170,25);
                l9.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l9);
                
                JLabel l10 = new JLabel("D.O.B");                            
                l10.setBounds(5,130,170,25);
                l10.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l10);
                
                JLabel l11 = new JLabel("Father,s name");                            
                l11.setBounds(225,5,170,25);
                l11.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l11);
                
                JLabel l12 = new JLabel("Mother's name");                            
                l12.setBounds(225,30,170,25);
                l12.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l12);
                
                JLabel l13 = new JLabel("Gender");                            
                l13.setBounds(225,55,170,25);
                l13.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l13);
                
                 JLabel l14 = new JLabel("Address");                            
                l14.setBounds(225,80,170,25);
                l14.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel4.add(l14);
                
                
       //--------         //uper text feilds//     ------------//
       
       
                t1 = new JTextField();
                t1.setEditable(false);
                t1.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t1.setForeground(new Color(72, 61, 139));   
                t1.setBounds(90,5,120,20);
                panel4.add(t1);
                
                t2 = new JTextField();
                t2.setEditable(false);
                t2.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t2.setForeground(new Color(72, 61, 139));
                t2.setBounds(90,30,120,20);
                panel4.add(t2);
                
                t3 = new JTextField();
                t3.setEditable(false);
                t3.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t3.setForeground(new Color(72, 61, 139));
                t3.setBounds(90,55,120,20);
                panel4.add(t3);
                
                t4 = new JTextField();
                t4.setEditable(false);
                t4.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t4.setForeground(new Color(72, 61, 139));
                t4.setBounds(90,80,120,20);
                panel4.add(t4);
                
                t5 = new JTextField();
                t5.setEditable(false);
                t5.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t5.setForeground(new Color(72, 61, 139));
                t5.setBounds(90,105,120,20);
                panel4.add(t5);
                
                t6 = new JTextField();
                t6.setEditable(false);
                t6.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t6.setForeground(new Color(72, 61, 139));
                t6.setBounds(90,130,120,20);
                panel4.add(t6);
                
                
                t7 = new JTextField();
                t7.setEditable(false);
                t7.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t7.setForeground(new Color(72, 61, 139));
                t7.setBounds(340,5,120,20);   //225,5,170,25
                panel4.add(t7);
                
                t8 = new JTextField();
                t8.setEditable(false);
                t8.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t8.setForeground(new Color(72, 61, 139));
                t8.setBounds(340,30,120,20);   
                panel4.add(t8);
                
                t9 = new JTextField();
                t9.setEditable(false);
                t9.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t9.setForeground(new Color(72, 61, 139));
                t9.setBounds(340,55,120,20);   
                panel4.add(t9);
                
                 textarea1 = new JTextArea(5, 20);
                textarea1.setEditable(false);
                textarea1.setBounds(340,85,122,60);
                panel4.add(textarea1);
                
                  //--------         //lower labels //     ------------//
                  
                  
                JLabel ll1 = new JLabel("Name");                            
                ll1.setBounds(5,5,100,25);
                ll1.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll1);
                
                JLabel ll2 = new JLabel("Branch");                            
                ll2.setBounds(5,30,130,25);
                ll2.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll2);
                
                JLabel ll3 = new JLabel("Year/sem");                            
                ll3.setBounds(5,55,170,25);
                ll3.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll3);
                
                JLabel ll4 = new JLabel("Phone no.");                            
                ll4.setBounds(5,80,170,25);
                ll4.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll4);
                
                JLabel ll5 = new JLabel("E-mail");                            
                ll5.setBounds(5,105,170,25);
                ll5.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll5);
                
                JLabel ll6 = new JLabel("D.O.B");                            
                ll6.setBounds(5,130,170,25);
                ll6.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll6);
                
                JLabel ll7 = new JLabel("Father's Name");                            
                ll7.setBounds(5,155,170,25);
                ll7.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll7);
                
                JLabel ll8 = new JLabel("Mother's Name");                            
                ll8.setBounds(5,180,170,25);
                ll8.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll8);
                
                JLabel ll9 = new JLabel("Gender");                            
                ll9.setBounds(270,5,100,25);
                ll9.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll9);
                
                JLabel ll10 = new JLabel("Address");                            
                ll10.setBounds(270,30,100,25);
                ll10.setFont(new Font("Times new roman", Font.BOLD, 16));
                panel6.add(ll10);
                
                
           //-----------------lower text feilds ----------------//
           
           
                tf1 = new JTextField(name);
                tf1.setEditable(false);
                tf1.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                tf1.setForeground(new Color(72, 61, 139));                             //name
                tf1.setBounds(120,5,120,20);
                panel6.add(tf1);
                
                comboBox1 = new JComboBox();                    
	        comboBox1.setModel(new DefaultComboBoxModel(new String[] { "CSE", "EE","ECE",
			"DE", "CE","ME","IT" }));
	        comboBox1.setBounds(120, 30, 130, 20);
	        panel6.add(comboBox1);
                
                comboBox2 = new JComboBox();                    
	        comboBox2.setModel(new DefaultComboBoxModel(new String[] { "1st year/1st sem", "1st year/1st sem","2nd year/3rd sem",
			"2nd year/4th sem", "3rd year/5th sem","3rd year/6th sem","4th year/7th sem","4th year/8th sem" }));
	        comboBox2.setBounds(120, 55, 130, 20);
	        panel6.add(comboBox2);
                
                tf4 = new JTextField();
                tf4.setFont(new Font("Times New Roman", Font.BOLD, 15));     //phone no
                tf4.setForeground(new Color(72, 61, 139));
                tf4.setBounds(120,80,120,20);
                panel6.add(tf4);
                
                tf5 = new JTextField();
                tf5.setFont(new Font("Times New Roman", Font.BOLD, 15));   //mail
                tf5.setForeground(new Color(72, 61, 139));
                tf5.setBounds(120,105,120,20);
                panel6.add(tf5);
                
                
                tf3 = new JTextField();
                tf3.setFont(new Font("Times New Roman", Font.BOLD, 15));   //dob
                tf3.setForeground(new Color(72, 61, 139));
                tf3.setBounds(120,130,120,20);
                panel6.add(tf3);
                
                tf7 = new JTextField();
                tf7.setFont(new Font("Times New Roman", Font.BOLD, 15));  //fathername
                tf7.setForeground(new Color(72, 61, 139));
                tf7.setBounds(120,155,120,20);
                panel6.add(tf7);
                
                tf8 = new JTextField();                             //mothername
                tf8.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                tf8.setForeground(new Color(72, 61, 139));
                tf8.setBounds(120,180,120,20);
                panel6.add(tf8);
               
                r1 = new JRadioButton("Male");
                r1.setFont(new Font("Raleway", Font.BOLD, 14));
                r1.setBackground(Color.WHITE);
                r1.setBounds(330, 6, 60, 17);
                panel6.add(r1);
                
                r2 = new JRadioButton("Female");
                r2.setFont(new Font("Raleway", Font.BOLD, 14));
                r2.setBackground(Color.WHITE);
                r2.setBounds(400, 6, 90, 17);
		panel6.add(r2);
                
                textarea = new JTextArea(5, 20);           //address
                JScrollPane scrollPane = new JScrollPane(textarea); 
               // textarea.setEditable(false);
                textarea.setBounds(330,31,160,90);
                panel6.add(textarea);
                
                b1 = new JButton("Remove photo");
                b1.setFont(new Font("Times new roman", Font.BOLD, 14));
                b1.setBounds(525, 210, 130, 25);              
                b1.setBackground(Color.BLACK);                                         
                b1.setForeground(Color.WHITE);
                panel2.add(b1);
                b1.addActionListener((ActionEvent e) -> {
                l2.setIcon(null);
                l4.setIcon(null);
                });
                
                b2 = new JButton("Add photo");
                b2.setFont(new Font("Times new roman", Font.BOLD, 14));
                b2.setBounds(535, 240, 110, 25);              
                b2.setBackground(Color.BLACK);
                b2.setForeground(Color.WHITE);
                b2.addActionListener(this);
                panel2.add(b2);
               
                b5 = new JButton("Back");
                b5.setFont(new Font("Times new roman", Font.BOLD, 14));
                b5.setBounds(545, 300, 90, 25);              
                b5.setBackground(Color.BLACK);
                b5.setForeground(Color.WHITE);
                b5.addActionListener(this);
                panel2.add(b5);
                
                b3 = new JButton("View Details");
                b3.setFont(new Font("Times new roman", Font.BOLD, 14));
                b3.setBounds(40, 220, 170, 25);              
                b3.setBackground(Color.BLACK);                                         
                b3.setForeground(Color.WHITE);
                b3.addActionListener(this);
                panel6.add(b3);
                
                b4 = new JButton("Add Details");
                b4.setFont(new Font("Times new roman", Font.BOLD, 14));
                b4.setBounds(290, 220, 170, 25);              
                b4.setBackground(Color.BLACK);                                         
                b4.setForeground(Color.WHITE);
                b4.addActionListener(this); 
                panel6.add(b4);
                
                 b6 = new JButton("Update Details");
                b6.setFont(new Font("Times new roman", Font.BOLD, 14));
                b6.setBounds(180, 260, 170, 25);              
                b6.setBackground(Color.BLACK);                                         
                b6.setForeground(Color.WHITE);
                b6.addActionListener(this);
                panel6.add(b6);
                
                try{
                Conn con = new Conn();
                String sql = "select * from stusignup where name =?";
                PreparedStatement st = con.c.prepareStatement(sql);
                ResultSet rs = st.executeQuery();
                 while(rs.next()){
                        tf1.setText(rs.getString("name"));
                    }
        }
                catch(Exception a){
                    //a.printStackTrace();
                }
    }
    
     public ImageIcon ResizeImage(String ImagePath)
    {
        ImageIcon MyImage = new ImageIcon(ImagePath);
        Image img = MyImage.getImage();
        Image img1 = MyImage.getImage();
        Image newImg = img.getScaledInstance(l2.getWidth(), l2.getHeight(), Image.SCALE_SMOOTH);
        Image newImg1 = img.getScaledInstance(l4.getWidth(), l4.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }
     
    public static void main(String args[]){
        EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Studentdetails1 frame = new Studentdetails1("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
        
       
}
    
    public void actionPerformed(ActionEvent e) {
      try{
          Conn con = new Conn();
           if(e.getSource() == b3){
            String sql = "select * from stuinfo where name = '"+name+"'";
            PreparedStatement st = con.c.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            if (rs.next() == false) {
             JOptionPane.showMessageDialog(null, "Please Enter the details");
             } else {
            while(rs.next()==true){
            t1.setText(rs.getString("name"));
            t2.setText(rs.getString("branch"));
            t3.setText(rs.getString("yearsem"));
            t4.setText(rs.getString("phoneno"));
            t5.setText(rs.getString("email"));
            t6.setText(rs.getString("dob"));
            t7.setText(rs.getString("fname"));
            t8.setText(rs.getString("mname"));
            t9.setText(rs.getString("gender"));
            textarea1.setText(rs.getString("address"));
           int i = st.executeUpdate();
            if (i > 0){
                                JOptionPane.showMessageDialog(null, "Your info");
                    this.setVisible(true);}
           }
        }
      }
           if(e.getSource() == b4){
            String radio = null;
            if(r1.isSelected()){
            radio="male";
            }
            else if(r2.isSelected()){
            radio="female";
            }
            String s1 = tf1.getText();          //name
            String s2 = (String)comboBox1.getSelectedItem();         //branch
            String s3 = (String)comboBox2.getSelectedItem();         //year sem
            String s4 =  tf4.getText();                                //phone no
            String s5 =  tf5.getText();      
            String s6 = tf3.getText();        
            String s7 =  tf7.getText();
            String s8 =  tf8.getText();
            String s9=   radio;
            String s10 =  textarea.getText();
           String sql = "insert into stuinfo values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"','"+s8+"','"+s9+"','"+s10+"')";      //'"+s6+"','"+s7+"','"+s8+"',
                         
                  PreparedStatement st = con.c.prepareStatement(sql);
                  int i = st.executeUpdate();
                   if (i > 0){
                     JOptionPane.showMessageDialog(null, "Details saved Successfully ");
                      }
      }
           
            if(e.getSource() == b6){
             String radio = null;
            if(r1.isSelected()){
            radio="male";
            }
            else if(r2.isSelected()){
            radio="female";
            } 
            String s1 = tf1.getText();
            String s2 = (String)comboBox1.getSelectedItem();         //combo box
            String s3 = (String)comboBox2.getSelectedItem();  
            String s4 = tf4.getText();
            String s5 = tf5.getText();			
            String s6 = tf3.getText();
            String s7 = tf7.getText(); 
            String s8 = tf8.getText();
            String s9=   radio;
            String s10 =  textarea.getText();
            String sql = "update stuinfo set branch= '"+s2+"',yearsem = '"+s3+"', phoneno = '"+s4+"', email = '"+s5+"', dob = '"+s6+"', fname = '"+s7+"', mname = '"+s8+"', gender = '"+s9+"', address = '"+s10+"' where name = '"+s1+"'";
            PreparedStatement st = con.c.prepareStatement(sql);
            con.s.executeUpdate(sql);
	    JOptionPane.showMessageDialog(null, "Detail Updated Successfully");
                setVisible(true);
	    		}
      
       if(e.getSource() == b5){
                setVisible(false);
		ProjectManagmntSystem ms = new ProjectManagmntSystem("");
		ms.setVisible(true);
       }
       if(e.getSource() == b2){
           
            JFileChooser file = new JFileChooser();
          file.setCurrentDirectory(new File(System.getProperty("user.home")));
         
          FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg","gif","png");       //filter the files
          file.addChoosableFileFilter(filter);
          int result = file.showSaveDialog(null);
          if(result == JFileChooser.APPROVE_OPTION){              //if the user click on save in Jfilechooser
              File selectedFile = file.getSelectedFile();
              String path = selectedFile.getAbsolutePath();
              l2.setIcon(ResizeImage(path));
              l4.setIcon(ResizeImage(path));
        
          }
          else if(result == JFileChooser.CANCEL_OPTION){            //if the user click on save in Jfilechooser
              System.out.println("No File Select");
          }
        }
             
       }
      
     

  catch(SQLException ae){}
     
    
}
}




