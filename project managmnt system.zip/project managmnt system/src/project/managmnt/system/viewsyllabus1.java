package project.managmnt.system;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;


public class viewsyllabus1 extends JFrame implements ActionListener{
    
      private JPanel panel;
      private JButton b1,b11,b12,b13,b14,b15;
     viewsyllabus1(){
     setTitle("View Syllabus");
                setPreferredSize(new Dimension(700,650));
                pack();
                setLocationRelativeTo(null);
                setResizable(false);
                
                panel = new JPanel();
                panel.setBackground(new Color(50,205,50));                          //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2), "View Syllabus",
                TitledBorder.LEADING, TitledBorder.TOP, null, Color.black));
                
                ImageIcon c1 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/viewsyllabus1.jpeg"));
                Image i1 = c1.getImage().getScaledInstance(50, 50,Image.SCALE_DEFAULT);
                ImageIcon i2 = new ImageIcon(i1);
                JLabel l1 = new JLabel(i2);
                l1.setBounds(5,10,130,130);
                add(l1);
                
                ImageIcon c2 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/viewsyllabus2.jpeg"));
                Image i3= c2.getImage().getScaledInstance(50, 50,Image.SCALE_DEFAULT);
                ImageIcon i4 = new ImageIcon(i3);
                JLabel l3 = new JLabel(i4);
                l3.setBounds(5,80,130,130);
                 add(l3);
                 
              
                JLabel la = new JLabel("SYLLABUS");                             
                la.setBounds(300,67,160,24);
                la.setForeground(Color.WHITE);
                la.setFont(new Font("Times new roman", Font.BOLD, 30));
                panel.add(la);  
                
                
                 JPanel panel2 = new JPanel();
                 panel2.setBackground(new Color(0,100,0));
                 panel2.setBounds(150,60,500,40);
                 panel2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                 panel2.setLayout(null);
                 panel.add(panel2);
                 
                  JPanel panel5 = new JPanel();
                 panel5.setBackground(new Color(124,252,0));
                 panel5.setBounds(130,30,530,100);
                 panel5.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                 panel5.setLayout(null);
                 panel.add(panel5);
                 
                
                ImageIcon c3 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/one.jpg"));
                Image i5= c3.getImage().getScaledInstance(50, 50,Image.SCALE_DEFAULT);
                ImageIcon i6= new ImageIcon(i5);
                JLabel l5 = new JLabel(i6);
                l5.setBounds(160,165,50,50);
                l5.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                add(l5);      
                 
                 JLabel JL5 = new JLabel("CSE");                             
                JL5.setBounds(230,176,100,24);
                JL5.setForeground(Color.BLACK);
                JL5.setFont(new Font("Times new roman", Font.BOLD, 30));
                panel.add(JL5); 
                
                b11 = new JButton("View pdf");
                b11.setFont(new Font("Times new roman", Font.BOLD, 20));
                b11.setBounds(433, 170, 120, 40);              
                b11.setBackground(new Color(218,112,214));
                b11.setForeground(Color.black);
                b11.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                b11.addActionListener(this);
                panel.add(b11);
                
                 b11.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent a){
                    try{
                        Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler "+"C:/Users/neela/OneDrive/Pictures/neelam/syllabus.pdf");
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, "check file details");
                    }
                }
                }
                );
                
                ImageIcon c4 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/two.jpg"));
                Image i7= c4.getImage().getScaledInstance(50, 50,Image.SCALE_DEFAULT);
                ImageIcon i8= new ImageIcon(i7);
                JLabel l7 = new JLabel(i8);
                l7.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                l7.setBounds(160,245,50,50);
                 add(l7); 
                 
                JLabel JL1 = new JLabel("ECE");                             
                JL1.setBounds(230,257,100,24);
                JL1.setForeground(Color.BLACK);
                JL1.setFont(new Font("Times new roman", Font.BOLD, 30));
                panel.add(JL1); 
                 
                b12 = new JButton("View pdf");
                b12.setFont(new Font("Times new roman", Font.BOLD, 20));
                b12.setBounds(433, 250, 120, 40);              
                b12.setBackground(new Color(218,112,214));
                b12.setForeground(Color.black);
                b12.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                b12.addActionListener(this);
                panel.add(b12);
                b12.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent a){
                    try{
                        Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler "+"C:/Users/neela/OneDrive/Pictures/neelam/syllabus.pdf");
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, "check file details");
                    }
                }
                }
                );
                
                
                ImageIcon c5 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/three.jpg"));
                Image i9= c5.getImage().getScaledInstance(50, 50,Image.SCALE_DEFAULT);
                ImageIcon i10= new ImageIcon(i9);
                JLabel l9 = new JLabel(i10);
                l9.setBounds(160,325,50,50);
                l9.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                 add(l9); 
                 
                JLabel JL2 = new JLabel("ME");                             
                JL2.setBounds(230,337,100,24);
                JL2.setForeground(Color.BLACK);
                JL2.setFont(new Font("Times new roman", Font.BOLD, 30));
                panel.add(JL2); 
                  
                b13 = new JButton("View pdf");
                b13.setFont(new Font("Times new roman", Font.BOLD, 20));
                b13.setBounds(433, 330, 120, 40);              
                b13.setBackground(new Color(218,112,214));
                b13.setForeground(Color.black);
                b13.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                b13.addActionListener(this);
                panel.add(b13);
                b13.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent a){
                    try{
                        Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler "+"C:/Users/neela/OneDrive/Pictures/neelam/syllabus.pdf");
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, "check file details");
                    }
                }
                }
                );
               
                
                 ImageIcon c6 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/four.jpg"));
                Image i11= c6.getImage().getScaledInstance(50, 50,Image.SCALE_DEFAULT);
                ImageIcon i12= new ImageIcon(i11);
                JLabel l11 = new JLabel(i12);
                l11.setBounds(160,405,50,50);
                l11.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                add(l11); 
                 
                JLabel JL3 = new JLabel("CE");                             
                JL3.setBounds(230,416,100,24);
                JL3.setForeground(Color.BLACK);
                JL3.setFont(new Font("Times new roman", Font.BOLD, 30));
                panel.add(JL3); 
                
                   
                b14 = new JButton("View pdf");
                b14.setFont(new Font("Times new roman", Font.BOLD, 20));
                b14.setBounds(433, 410, 120, 40);              
                b14.setBackground(new Color(218,112,214));
                b14.setForeground(Color.black);
                b14.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                b14.addActionListener(this);
                panel.add(b14);
                
                b14.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent a){
                    try{
                        Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler "+"C:/Users/neela/OneDrive/Pictures/neelam/syllabus.pdf");
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, "check file details");
                    }
                }
                }
                );
                 
                ImageIcon c7 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/five.jpg"));
                Image i13= c7.getImage().getScaledInstance(50, 50,Image.SCALE_DEFAULT);
                ImageIcon i14= new ImageIcon(i13);
                JLabel l13 = new JLabel(i14);
                l13.setBounds(160,485,50,50);
                l13.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                 add(l13); 

                JLabel JL4 = new JLabel("MLT");                             
                JL4.setBounds(230,495,100,24);
                JL4.setForeground(Color.BLACK);
                JL4.setFont(new Font("Times new roman", Font.BOLD, 30));
                panel.add(JL4); 
                
                b15 = new JButton("View pdf");
                b15.setFont(new Font("Times new roman", Font.BOLD, 20));
                b15.setBounds(433, 490, 120, 40);              
                b15.setBackground(new Color(218,112,214));
                b15.setForeground(Color.black);
                b15.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                b15.addActionListener(this);
                panel.add(b15);  
                b15.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent a){
                    try{
                        Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler "+"C:/Users/neela/OneDrive/Pictures/neelam/syllabus.pdf");
                    }
                    catch(Exception e){
                        JOptionPane.showMessageDialog(null, "check file details");
                    }
                }
                }
                );
                
                JPanel panel4 = new JPanel();
                panel4.setBackground(new Color(0,128,0));
                panel4.setBounds(20,25,100,570);
                panel4.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel4.setLayout(null);
                panel.add(panel4);
                
                 JPanel panel3 = new JPanel();
                 panel3.setBackground(Color.white);
                 panel3.setBounds(150,170,400,40);
                 panel3.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                 panel3.setLayout(null);
                 panel.add(panel3);   
                 
                 JPanel panel6 = new JPanel();
                 panel6.setBackground(Color.white);
                 panel6.setBounds(150,250,400,40);
                 panel6.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                 panel6.setLayout(null);
                 panel.add(panel6);   
               
                 JPanel panel7 = new JPanel();
                 panel7.setBackground(Color.white);
                 panel7.setBounds(150,330,400,40);
                 panel7.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                 panel7.setLayout(null);
                 panel.add(panel7); 
                 
                 JPanel panel8 = new JPanel();
                 panel8.setBackground(Color.white);
                 panel8.setBounds(150,410,400,40);
                 panel8.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                 panel8.setLayout(null);
                 panel.add(panel8); 
              
                 JPanel panel9 = new JPanel();
                 panel9.setBackground(Color.white);
                 panel9.setBounds(150,490,400,40);
                 panel9.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                 panel9.setLayout(null);
                 panel.add(panel9); 
                
                 b1 = new JButton("Back");
                b1.setFont(new Font("Times new roman", Font.BOLD, 14));
                b1.setBounds(565, 565, 90, 25);              
                b1.setBackground(Color.BLACK);
                b1.setForeground(Color.WHITE);
                b1.addActionListener(this);
                panel.add(b1);
              
	
}

 public static void main(String args[]){
        new viewsyllabus1().setVisible(true);
    }
 
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b1){
                setVisible(false);
		ProjectManagmntSystem ms = new ProjectManagmntSystem("");
		ms.setVisible(true);
         }
    }
}