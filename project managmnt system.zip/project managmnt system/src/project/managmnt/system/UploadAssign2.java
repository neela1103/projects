package project.managmnt.system;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;

public class UploadAssign2 extends JFrame implements ActionListener{
        JPanel panel;
        JButton b1,b2,b3;
        JFileChooser filechooser;
        File filetosend;
        static Socket s;
            UploadAssign2(){
                setPreferredSize(new Dimension(400,200));
                pack();
                setLocationRelativeTo(null);
                setResizable(false);
                panel = new JPanel();
                panel.setBackground(Color.white);                            //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
               
                JPanel panel1= new JPanel();
                panel1.setBackground(Color.pink);
                panel1.setBounds(3,8, 380, 30);
                panel1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel1);
               
                JLabel l = new JLabel("Select your file ");
                l.setBounds(40,4,190,25);
                //l.setBackground(Color.pink);
                l.setFont(new Font("Times new roman", Font.BOLD, 18));
                panel1.add(l);
               
                JButton b1 = new JButton("choose File");
                b1.setBackground(Color.pink);
                b1.setForeground(Color.black);
                b1.setBounds(55,75,120,30);
                b1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(b1);
               
                b1.addActionListener(new ActionListener(){
               
                public void actionPerformed(ActionEvent e) {
               
                filechooser = new JFileChooser();
                filechooser.setDialogTitle("Choose a File to Send");
               
                if(filechooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
                   
                    filetosend = filechooser.getSelectedFile();
                    l.setText("File is : "+filetosend.getName());
                }
            }
       
    });
                JButton b2 = new JButton("Upload File");
                b2.setBackground(Color.pink);
                b2.setForeground(Color.black);
                b2.setBounds(190,75,120,30);
                b2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(b2);
                b2.addActionListener(new ActionListener(){
               
                public void actionPerformed(ActionEvent e) {
                if (filetosend == null){
                    l.setText("Please Choose a File First.");
                    }else{
                            try {
                                FileInputStream fileInputStream = new FileInputStream(filetosend.getAbsolutePath());
                                Socket s = new Socket("localhost", 9004);
                       
                                DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());
                       
                                String fileName = filetosend.getName();
                                byte[] fileNameBytes = fileName.getBytes();
                       
                                byte[] fileContentBytes = new byte[(int) filetosend.length()];
                                fileInputStream.read(fileContentBytes);
                       
                                dataOutputStream.writeInt(fileNameBytes.length);
                                dataOutputStream.write(fileNameBytes);
                       
                                dataOutputStream.writeInt(fileContentBytes.length);
                                dataOutputStream.write(fileContentBytes);
                       
                            }catch (IOException error){
                                error.printStackTrace();
                            }
                   
                        }
                }
       

            });
               
                JButton b3 = new JButton("File");
                b3.setBackground(Color.black);
                b3.setForeground(Color.white);
                b3.setBounds(125,85,120,30);
               //panel.add(b3);
            }
   
    public static void main(String args[]){
     new UploadAssign2().setVisible(true);
    }
   
    public void actionPerformed(ActionEvent e) {
    }      
}
/*package project.managmnt.system;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;

public class UploadAssign2 extends JFrame implements ActionListener{
        JPanel panel;
        JButton b1,b2,b3;
        JFileChooser jFilechooser;
        final File[] filetoSend = new File[1];
        FileInputStream
            UploadAssign2(){
              setPreferredSize(new Dimension(300,200));
                 pack();
                setLocationRelativeTo(null);
                setResizable(false);
                panel = new JPanel();
                panel.setBackground(Color.white);                            //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                
                JPanel panel1= new JPanel();
                panel1.setBackground(Color.pink); 
                panel1.setBounds(3,8, 280, 30); 
                panel1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel1);
                
                JLabel l = new JLabel("Choose your file ");
                l.setBounds(40,4,190,25);
                //l.setBackground(Color.pink);
                l.setFont(new Font("Times new roman", Font.BOLD, 18));
                panel1.add(l);
                
                 b1 = new JButton("choose File");
                b1.setBackground(Color.pink);
                b1.setForeground(Color.black);
                b1.setBounds(15,75,120,30);
                b1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(b1);
                b1.addActionListener(this);
               // JFileChooser jFilechooser = new JFileChooser();
                b1.addActionListener(new ActionListener(){
                 public void actionPerformed(ActionEvent e) {
                      JFileChooser jFileChooser = new JFileChooser();
                      jFileChooser.setDialogTitle("Choose a file to send");
                      if(jFileChooser.showOpenDialog(null) == jFilechooser.APPROVE_OPTION){
                     filetoSend[0] = jFileChooser.getSelectedFile();
                     l.setText("The file you want to send is:" +filetoSend[0].getName());
                     }                                                                                                                                                                                                                                                                      
                }
              }
            );
                b2 = new JButton("Upload File");
                b2.setBackground(Color.pink);
                b2.setForeground(Color.black);
                b2.setBounds(150,75,120,30);
                b2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(b2);
                b2.addActionListener(new ActionListener (){
                public void actionPerformed(ActionEvent ae){
                if(filetoSend[0] == null){
                l.setText("Please choose a file first:");
                }else{
                    try{
                FileInputStream fileInputStream = new FileInputStream(filetoSend[0].getAbsolutePath());
                Socket socket = new Socket("localhost",1235);
                DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                String fileName = filetoSend.getName();
                byte[] fileNameBytes = fileName.getBytes();
                
                byte[] fileContentBytes = new byte[(int)filetoSend[0].length()];
                fileInputStream.read(fileContentBytes);
                
                dataOutputStream.write(fileNameBytes.length);
                dataOutputStream.write(fileNameBytes);
                
                 dataOutputStream.write(fileContentBytes.length);
                dataOutputStream.write(fileContentBytes);
                
                }
                    catch(IOException error){
                    error.printStackTrace();
                    }
                }
                }
            
            });
                
                b3 = new JButton("back");
                b3.setBackground(Color.black);
                b3.setForeground(Color.white);
                b3.setBounds(95,120,90,25);
                b3.addActionListener(this);
                 panel.add(b3); 
            //return null;
            }
    
    public static void main(String args[]){
     new UploadAssign2().setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
       if(ae.getSource() == b3){
                setVisible(false);
		UploadAssign1 ua1 = new UploadAssign1();
		ua1.setVisible(true);
            }
    }      
}*/
