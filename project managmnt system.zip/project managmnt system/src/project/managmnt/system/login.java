
package project.managmnt.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.sql.*;

public class login extends JFrame implements ActionListener{
   private JPanel panel;
   private JButton b1,b2,b3,b4;
   private JTextField t1,t3;
   private JPasswordField t2;
    
    login(){
     setTitle("Login");
     setPreferredSize(new Dimension(660,400));
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        panel = new JPanel();
        panel.setBackground(Color.white);
	setContentPane(panel);
        panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 10), "Login Here!! ",
			TitledBorder.LEADING, TitledBorder.TOP, null, Color.red)); //new Color(34, 139, 34)));
        panel.setLayout(null);
     
        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.pink);
        panel2.setBounds(20,20,360,320);
        panel2.setLayout(null);
        panel.add(panel2);
       
        ImageIcon c1 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/Login.jpg"));
        Image i1 = c1.getImage().getScaledInstance(200, 200,Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i1);
        
        JLabel l1 = new JLabel(i2);
        l1.setBounds(420,80,180,180);
        add(l1);
        
        JPanel panel3 = new JPanel();
        panel3.setBackground(Color.pink);
        panel3.setBounds(400,60,220,220);
        panel.add(panel3);
       
        JLabel l2 = new JLabel("Name:");
        l2.setBounds(10, 20, 120, 40);
        l2.setFont(new Font("Tahoma", Font.BOLD, 18));
        panel2.add(l2);
        
        t1 = new JTextField();
        t1.setBounds(120,27,150,30);
         t1.setFont(new Font("Arial", Font.BOLD, 18));
        panel2.add(t1);
        
        JLabel l4 = new JLabel("UserName:");
        l4.setBounds(10, 60, 120, 40);
        l4.setFont(new Font("Tahoma", Font.BOLD, 18));
        panel2.add(l4);
        
        t3 = new JTextField();
        t3.setBounds(120,65,150,30);
         t3.setFont(new Font("Arial", Font.BOLD, 18));
        panel2.add(t3);
        
        JLabel l3 = new JLabel("Password:");
        l3.setBounds(10, 100, 120, 40);
        l3.setFont(new Font("Tahoma", Font.BOLD, 18));
        panel2.add(l3);
        
        t2 = new JPasswordField();
        t2.setBounds(120,107,150,30);
        t2.setFont(new Font("Arial", Font.BOLD, 18));
        panel2.add(t2);
        
        b1 = new JButton("Login");
        b1.setBounds(30,160,120,30);
        b1.setBackground(new Color(250,128,114));
        b1.setForeground(Color.white);
        b1.setFont(new Font("Arial", Font.BOLD, 18));
        b1.addActionListener(this);
        panel2.add(b1);
        
         
        b2 = new JButton("Sign up");
        b2.setBounds(205,160,120,30);
        b2.setBackground(new Color(250,128,114));
        b2.setForeground(Color.white);
        b2.setFont(new Font("Arial", Font.BOLD, 18));
        b2.addActionListener(this); 
        panel2.add(b2);
        
        b3 = new JButton("Forget Password");
        b3.setBounds(75,220,200,40);
        b3.setBackground(new Color(255,99,71));
        b3.setForeground(Color.white);
        b3.setFont(new Font("Arial", Font.BOLD, 18));
        b3.addActionListener(this); 
        panel2.add(b3);   
        
        b4 = new JButton("Back");
        b4.setBounds(533,317,90,25);
        b4.setBackground(new Color(250,128,114));
        b4.setForeground(Color.white);
        b4.setFont(new Font("times new roman", Font.BOLD, 17));
        b4.addActionListener(this); 
        panel.add(b4);   
    }
    
    public static void main(String args[]){
        new login().setVisible(true);
    }

  
    public void actionPerformed(ActionEvent e) {
         if(e.getSource() == b1){
              //  Boolean status= false;
                try{
                Conn con = new Conn();
                String sql = "select * from stusignup where name =? and username=? and password=?";
                PreparedStatement st = con.c.prepareStatement(sql);
                
                st.setString(1,t1.getText());        //name
                st.setString(2,t3.getText());           //username
                st.setString(3,t2.getText());
                
                ResultSet rs = st.executeQuery();
                if(rs.next()){
                this.setVisible(false);
                String name = t1.getText();
                ProjectManagmntSystem pm = new ProjectManagmntSystem(name);
		pm.setVisible(true);
                }else{
                JOptionPane.showMessageDialog(null,"Invalid username or password");}
                }
                catch(Exception a){
                    a.printStackTrace();
                }
         }  
        if(e.getSource() == b2){
                setVisible(false);
		SignUp1 ss = new SignUp1();
		ss.setVisible(true);
            }   
            if(e.getSource() == b3){
                setVisible(false);
		Forgetpassword forgot = new Forgetpassword();
		forgot.setVisible(true);
            }
            if(e.getSource() == b4){
                setVisible(false);
		loginchoice1 lc = new loginchoice1();
		lc.setVisible(true);
            }
    }
}












/*import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener{

	private JPanel panel;
	private JTextField textField;
	private JPasswordField passwordField;
        private JButton b1,b2,b3;

	public Login() {
            
	setBackground(new Color(255, 255, 204));	
        setBounds(350, 200, 700, 400);

        panel = new JPanel();
	panel.setBackground(Color.WHITE);
	setContentPane(panel);
	panel.setLayout(null);

	JLabel l1 = new JLabel("Username : ");
	l1.setBounds(124, 89, 95, 24);
	panel.add(l1);

	JLabel l2 = new JLabel("Password : ");
	l2.setBounds(124, 124, 95, 24);
	panel.add(l2);

	textField = new JTextField();
	textField.setBounds(210, 93, 157, 20);
	panel.add(textField);
	
	passwordField = new JPasswordField();
	passwordField.setBounds(210, 128, 157, 20);
	panel.add(passwordField);

	JLabel l3 = new JLabel("");
	l3.setBounds(377, 79, 46, 34);
	panel.add(l3);

	JLabel l4 = new JLabel("");
	l4.setBounds(377, 124, 46, 34);
	panel.add(l3);

        ImageIcon c1 = new ImageIcon(ClassLoader.getSystemResource("Travel/Management/System/icons/login.png"));
        Image i1 = c1.getImage().getScaledInstance(150, 150,Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i1);

        JLabel l6 = new JLabel(i2);
        l6.setBounds(480, 70, 150, 150);
        add(l6);
        
        
	b1 = new JButton("Login");
	b1.addActionListener(this);
                
	b1.setForeground(new Color(46, 139, 87));
	b1.setBackground(new Color(176, 224, 230));
	b1.setBounds(149, 181, 113, 25);
	panel.add(b1);
		
        b2 = new JButton("SignUp");
	b2.addActionListener(this);
	
	b2.setForeground(new Color(139, 69, 19));
	b2.setBackground(new Color(255, 235, 205));
	b2.setBounds(289, 181, 113, 25);
	panel.add(b2);

	b3 = new JButton("Forgot Password");
	b3.addActionListener(this);
	
        b3.setForeground(new Color(205, 92, 92));
	b3.setBackground(new Color(253, 245, 230));
	b3.setBounds(199, 231, 179, 25);
	panel.add(b3);

	JLabel l5 = new JLabel("Trouble in Login?");
	l5.setFont(new Font("Tahoma", Font.PLAIN, 15));
	l5.setForeground(new Color(255, 0, 0));
	l5.setBounds(70, 235, 110, 20);
	panel.add(l5);

        JPanel panel2 = new JPanel();
        panel2.setBackground(new Color(255, 255, 204));
        panel2.setBounds(24, 40, 434, 263);
        panel.add(panel2);
	}
        
        public void actionPerformed(ActionEvent ae){
            if(ae.getSource() == b1){
                Boolean status = false;
		try {
                    Conn con = new Conn();
                    String sql = "select * from account where username=? and password=?";
                    PreparedStatement st = con.c.prepareStatement(sql);

                    st.setString(1, textField.getText());
                    st.setString(2, passwordField.getText());

                    ResultSet rs = st.executeQuery();
                    if (rs.next()) {
                        this.setVisible(false);
                        new Loading(textField.getText()).setVisible(true);
                    } else
			JOptionPane.showMessageDialog(null, "Invalid Login or Password!");
                       
		} catch (Exception e2) {
                    e2.printStackTrace();
		}
            }
            if(ae.getSource() == b2){
                setVisible(false);
		Signup su = new Signup();
		su.setVisible(true);
            }   
            if(ae.getSource() == b3){
                setVisible(false);
		ForgotPassword forgot = new ForgotPassword();
		forgot.setVisible(true);
            }
        }
        
  	public static void main(String[] args) {
                new Login().setVisible(true);
	}

}*/