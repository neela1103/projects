


package project.managmnt.system;
 import javax.swing.JFrame;
 import javax.swing.JScrollPane;
 import javax.swing.JTable;
                public class Timetable1 {
                JFrame fr;
                JTable jt;
                Timetable1()
                {
                fr = new JFrame();
                fr.setTitle("Student management system");
                fr.setBounds(260,150,700,170);
                String[][] d = {
                { "8:00-8:45", "AM-1" ," AP-1"," LAB","CS","OS" },
                { "9:00-9:45", " AP-1 ", "LAB","IT","BE","OS"},
                { "10:00-10:45", "AM-1" ," AP-1"," LAB","CS","OS" },
                { "11:00-11:45", " AP-1 ", "LAB","IT","BE","MP" },
                { "12:00-12:45", "AM-1" ," AP-1"," LAB","CS","MP" }
                };
                String[] cn = { "Timings","Monday", "Tuesday", "Wednesday","Thursday","Friday" };
                jt = new JTable(d, cn);
                JScrollPane jsp = new JScrollPane(jt);
                fr.add(jsp);
                fr.setVisible(true);
                }
                public static void main(String[] args)
                {
                 new Timetable1().setVisible(true);
                }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
                }