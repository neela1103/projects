package project.managmnt.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.border.*;

public class Teacherlogin extends JFrame implements ActionListener{
    private JPanel panel;
    private JButton b1,b2;
   JTextField t1;
   JPasswordField t2;
   String username;
    Teacherlogin(String username){
       this.username= username;
      setTitle("Teacher Login");
      setPreferredSize(new Dimension(400,500));
      pack();
      setLocationRelativeTo(null);
      setResizable(false);

      panel = new JPanel();
      panel.setBackground(Color.WHITE);
      setContentPane(panel);
      panel.setBorder(new TitledBorder(new LineBorder(new Color(30,144,255), 9)));
      //TitledBorder.LEADING, TitledBorder.TOP,null,Color.RED));
      panel.setLayout(null);
      
      ImageIcon c1 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/teacherloginp.png"));
       Image i1 = c1.getImage().getScaledInstance(170,150,Image.SCALE_DEFAULT);
       ImageIcon i2 = new ImageIcon(i1);
       
       JLabel l1 = new JLabel(i2);
       l1.setBounds(105,20,170,150);
       add(l1);
    
      JPanel panel3 = new JPanel();
       panel3.setBackground(new Color(225,218,185));
       panel3.setBounds(130,30,120,120);
       panel.add(panel3);
       
       JPanel panel2 = new JPanel();
       panel2.setBackground(new Color(225,218,185));
       panel2.setBounds(9,9,368,445);
       panel2.setLayout(null);
       panel.add(panel2);
       
       
       
      JLabel l2 = new JLabel("Username:");
      l2.setBounds(130,160,120,40);
      l2.setFont(new Font("Tahoma", Font.BOLD, 18));
      panel2.add(l2);
      
      t1 = new JTextField();
      t1.setBounds(108,200,150,30);
      t1.setFont(new Font("Aial",Font.BOLD, 18));
      panel2.add(t1);
      
      JLabel l3 = new JLabel("Password :");
      l3.setBounds(130,240,120,40);
      l3.setFont(new Font("Tahoma", Font.BOLD, 18));
      panel2.add(l3);
      
      t2 = new JPasswordField();
      t2.setBounds(108,280,150,30);
      t2.setFont(new Font("Aial",Font.BOLD, 18));
      panel2.add(t2);
    
      b1 = new JButton("Login");
      b1.setBounds(36,350, 115, 30);
      b1.setBackground(new Color(244,164,96));
      b1.setForeground(Color.WHITE);
      b1.setFont(new Font("Arial",Font.BOLD, 18));
      b1.addActionListener(this);
      panel2.add(b1);
      
      b2 = new JButton("Back");
      b2.setBounds(200,350, 115, 30);
      b2.setBackground(new Color(244,164,96));
      b2.setForeground(Color.WHITE);
      b2.setFont(new Font("Arial",Font.BOLD, 18));
      b2.addActionListener(this);
      panel2.add(b2);
    
    }  
    public static void main(String agr[]){
        new Teacherlogin("").setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
      if(e.getSource() == b1){
              //  Boolean status= false;
                try{
                Conn con = new Conn();
                String sql = "select * from tlogin where username=? and password=?";
                PreparedStatement st = con.c.prepareStatement(sql);
                
                st.setString(1,t1.getText());   //username
                st.setString(2,t2.getText());   //password
                ResultSet rs = st.executeQuery();
                if(rs.next()){
                this.setVisible(false);
                String username = t1.getText();
                TeacherZone tz = new TeacherZone(username);
		tz.setVisible(true);
                }else{
                JOptionPane.showMessageDialog(null,"Invalid username or password");}
                 if(e.getSource() == b2){
                setVisible(false);
		loginchoice1 lc = new loginchoice1();
		lc.setVisible(true);
            
            }
                }catch(Exception a){
                    a.printStackTrace();
                }
       
    
      }}}



//if(e.getSource() == b1){
//           
//                setVisible(false);
//		TeacherZone tz = new TeacherZone();
//		tz.setVisible(true);
//         }  
//        if(e.getSource() == b2){
//                setVisible(false);
//		loginchoice1 lc = new loginchoice1();
//		lc.setVisible(true);
//            
//            }