package project.managmnt.system;

import java.awt.Dimension;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;


public class loginchoice1 extends JFrame implements ActionListener {          //ActionListener
    JPanel panel;
    JButton J1,J2;
     public static void main(String args[]){
            new loginchoice1().setVisible(true);}
    
    loginchoice1(){
        setTitle("Project Management System");
        setPreferredSize(new Dimension(495,330));
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
       
        panel = new JPanel();
        panel.setBackground(new Color(230,230,250));                                        //230,230,250
        panel.setLayout(null);
        setContentPane(panel);                                                       //full panel
            panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2), "Login choice",
                TitledBorder.LEADING, TitledBorder.TOP, null, Color.black));
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/loginasstudent.png"));
        Image i2 = i1.getImage().getScaledInstance(200, 200,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        
        JLabel l1 = new JLabel(i3);
        l1.setBounds(30,45,190,160);                        //label for first imge
        l1.setBackground(Color.white);
        panel.add(l1);
        
        JPanel panel3 = new JPanel();
        panel3.setBackground(new Color(230,230,250));
        panel3.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
        panel3.setBounds(25,40,200,170);                              
        panel.add(panel3);
        
        J1 = new JButton("Login as student");
        J1.setBounds(55,230, 140,40);
        J1.setBackground(new Color(176,196,222));
        J1.setForeground(Color.black);
        J1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
        panel.add(J1);
        
        J1.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent a){
             if(a.getSource() == J1){                        
                setVisible(false);
             new login().setVisible(true);
            }
        }
   });
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/loginasteacher.png"));
        Image i5 = i4.getImage().getScaledInstance(200, 200,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel l2 = new JLabel(i6);
        
        l2.setBounds(260,45,190,160);
        l2.setBackground(Color.white);
        panel.add(l2);
        
        JPanel panel4 = new JPanel();
        panel4.setBackground(new Color(230,230,250));
        panel4.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
        panel4.setBounds(255,40,200,170);
        panel.add(panel4);
        
        J2 = new JButton("Login as teacher");
        J2.setBounds(290,230, 140,40);
        J2.setBackground(new Color(176,196,222));
        J2.setForeground(Color.black);
        J2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
        panel.add(J2);
        
        J2.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent a){
             if(a.getSource() == J2){                        
                setVisible(false);
             new Teacherlogin("").setVisible(true);
            }
        }
   });
        
    }
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
           
}

    
 