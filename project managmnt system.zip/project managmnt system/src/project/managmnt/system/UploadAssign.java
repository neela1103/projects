
package project.managmnt.system;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class UploadAssign extends JFrame implements ActionListener{
    JPanel panel;
    JButton b1,b2,b3,b4,b5,b6;
    UploadAssign(){
    setPreferredSize(new Dimension(560,250));
                pack();
                setLocationRelativeTo(null);
                setResizable(false);
                
                panel = new JPanel();
                panel.setBackground(new Color(255,192,203));                            //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                
                JPanel panel1 = new JPanel();
               // panel1 = new JPanel();
                panel1.setBackground(Color.pink); 
                panel1.setBounds(3,4,540,30);                                                 // panel for label
                panel1.setLayout(null);
                setContentPane(panel);
                panel1.setBorder(new TitledBorder(new LineBorder(Color.black, 2)));
                panel.add(panel1);
                
                JLabel l = new JLabel("Upload Your Assigment");
                l.setBounds(170,4,190,25);
               l.setBackground(Color.pink);
              //  l.setForeground(Color.black);
                l.setFont(new Font("Times new roman", Font.BOLD, 18));
                panel1.add(l);
                
                JPanel panel2 = new JPanel();
                panel2 = new JPanel();
                panel2.setBackground(Color.pink); 
                panel2.setBounds(3,38,540,35);                                            // panel for buttons
                panel2.setLayout(null);
                setContentPane(panel);
                panel2.setBorder(new TitledBorder(new LineBorder(Color.black, 2)));
                panel.add(panel2);
                
                b1 = new JButton("Branch CSE");
                b1.setBackground(Color.black);
                b1.setForeground(Color.pink);
                b1.setBounds(6,5,110,25);
                b1.addActionListener(this);
                panel2.add(b1);
                
                b2 = new JButton("Branch ECE");
                b2.setBackground(Color.black);
                b2.setForeground(Color.pink);
                b2.setBounds(118,5,110,25);
                b2.addActionListener(this);
                panel2.add(b2);
                
                b3 = new JButton("Branch EE");
                b3.setBackground(Color.black);
                b3.setForeground(Color.pink);
                b3.setBounds(230,5,100,25);
                b3.addActionListener(this);
                panel2.add(b3);
                
                b4 = new JButton("Branch DE");
                b4.setBackground(Color.black);
                b4.setForeground(Color.pink);
                b4.setBounds(332,5,100,25);
                b4.addActionListener(this);
                panel2.add(b4);
                
                b5 = new JButton("Branch CE");
                b5.setBackground(Color.black);
                b5.setForeground(Color.pink);
                b5.setBounds(434,5,100,25);
                b5.addActionListener(this);
                panel2.add(b5); 
                
                b6 = new JButton("back");
                b6.setBackground(Color.black);
                b6.setForeground(Color.pink);
                b6.setBounds(436,175,100,25);
                b6.addActionListener(this);
                panel.add(b6); 
                
    }
    
    
    public static void main(String args[]){
    new UploadAssign().setVisible(true);}

    
    public void actionPerformed(ActionEvent e) {
         if(e.getSource() == b1){
                setVisible(false);
		UploadAssign1 ua1 = new UploadAssign1();
		ua1.setVisible(true);
            }
          if(e.getSource() == b2){
                setVisible(false);
		UploadAssign1 ua1 = new UploadAssign1();
		ua1.setVisible(true);
            }
           if(e.getSource() == b3){
                setVisible(false);
		UploadAssign1 ua1 = new UploadAssign1();
		ua1.setVisible(true);
                
            } if(e.getSource() == b4){
                setVisible(false);
		UploadAssign1 ua1 = new UploadAssign1();
		ua1.setVisible(true);
            }
             if(e.getSource() == b5){
                setVisible(false);
		UploadAssign1 ua1 = new UploadAssign1();
		ua1.setVisible(true);
            }
           
            if(e.getSource() == b6){
                setVisible(false);
		ProjectManagmntSystem pms = new ProjectManagmntSystem("");
		pms.setVisible(true);
            }
    }
}
