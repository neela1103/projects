
package project.managmnt.system;

import javax.swing.JFrame;
 import javax.swing.JScrollPane;
 import javax.swing.JTable;

public class TeaTimeTable  {
    JFrame fr;
    JTable jt;
    TeaTimeTable(){
    fr = new JFrame();
                fr.setTitle("Student management system");
                fr.setBounds(260,150,700,170);
                String[][] d = {
                { "8:00-8:45", "AM-1(Taruna)" ,"STLD(Gurpreet)","Cns(Savita)","DS(Usha)","SE(indu)" },
                { "9:00-9:45", "STLD(Gurpreet)", "DS(Usha)","SE(indu)","AM-1(Taruna)","Cns(Savita)"},
                { "10:00-10:45", "SE(indu)","DS(Usha)"," Cns(Savita)","AM-1(Taruna)","STLD(Gurpreet)" },
                { "11:00-11:45", "AM-1(Taruna)","SE(indu)","STLD(Gurpreet)","Cns(Savita)","DS(Usha)" },
                { "12:00-12:45", "STLD(Gurpreet)","DS(Usha)","SE(indu)","AM-1(Taruna)","Cns(Savita)" }
                };
                String[] cn = { "Timings","Monday", "Tuesday", "Wednesday","Thursday","Friday" };
                jt = new JTable(d, cn);
                JScrollPane jsp = new JScrollPane(jt);
                fr.add(jsp);
                fr.setVisible(true);
    
    }
    
                public static void main(String args[]){
                TeaTimeTable ttt = new TeaTimeTable();
                ttt.setVisible(true);
                }

    public  void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
  