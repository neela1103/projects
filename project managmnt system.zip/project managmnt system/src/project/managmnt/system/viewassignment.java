
package project.managmnt.system;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;


public class viewassignment extends JFrame implements ActionListener{
    
                JFrame fr;
                JTable jt;
                private JPanel panel;
                private JTextField t1,t2,t3,t4,t5;
                private JButton b1;
                viewassignment()
                {
                setTitle("View Syllabus");
                setPreferredSize(new Dimension(700,650));
                pack();
                setLocationRelativeTo(null);
                setResizable(false);
                
                panel = new JPanel();
                panel.setBackground(new Color(0,191,255));  //(175,238,238)                          //main frame
                panel.setLayout(null);
                setContentPane(panel);
                
                JLabel JL1 = new JLabel("VIEW ASSIGNMENT");                             
                JL1.setBounds(235,37,400,24);
                JL1.setForeground(Color.BLACK);
                JL1.setFont(new Font("Times new roman", Font.BOLD, 30));
                panel.add(JL1);
                
                JPanel panel1 = new JPanel();
                panel1.setBackground(new Color(175,238,238)); //(70,130,180)        //view assigmnt wala panel
                panel1.setBounds(0,27,682,40);
                panel1.setLayout(null);                                                
                panel1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel1);
                
               
                
                JPanel panel2 = new JPanel();
                panel2.setBackground(new Color(25,25,112)); //(70,130,180)            //vertical panel dark blue
                panel2.setBounds(10,0,50,630);
                panel2.setLayout(null);                                                 
                panel2.setBorder(new TitledBorder(new LineBorder(Color.WHITE, 2)));
                panel.add(panel2);
                
                JLabel JL2 = new JLabel("Subject ");                                 //according to the main frame
                JL2.setBounds(150,140,150,50);
                JL2.setForeground(Color.BLACK);
                JL2.setFont(new Font("Times new roman", Font.PLAIN,30));
                panel.add(JL2); 
                
                JLabel JL3 = new JLabel("Topic ");                             
                JL3.setBounds(150,220,150,50);
                JL3.setForeground(Color.BLACK);
                JL3.setFont(new Font("Times new roman", Font.PLAIN,30));
                panel.add(JL3); 
                
                JLabel JL4 = new JLabel("Due Date");                             
                JL4.setBounds(150,300,150,50);
                JL4.setForeground(Color.BLACK);
                JL4.setFont(new Font("Times new roman", Font.PLAIN,30));
                panel.add(JL4); 
                
                 JLabel JL5 = new JLabel("Submission Status");                             
                JL5.setBounds(110,380,250,50);
                JL5.setForeground(Color.BLACK);
                JL5.setFont(new Font("Times new roman", Font.PLAIN,30));
                panel.add(JL5); 
                
                 JLabel JL6= new JLabel("Marks");                             
                JL6.setBounds(160,460,250,50);
                JL6.setForeground(Color.BLACK);
                JL6.setFont(new Font("Times new roman", Font.PLAIN,30));
                panel.add(JL6); 
                
                t1 = new JTextField();
                t1.setFont(new Font("Times New Roman", Font.BOLD, 15));  
                t1.setForeground(new Color(72, 61, 139));   
                t1.setBounds(400,140,200,50);
                panel.add(t1);
                
                 JPanel panel3 = new JPanel();
                 panel3.setBackground(new Color(221,160,221));  //(240,230,140)                      //dark pink jispe content hai
                 panel3.setBounds(100,130,530,400);
                 panel3.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                 panel3.setLayout(null);
                 panel.add(panel3); 
                
                JPanel panel4= new JPanel();
                panel4.setBackground(new Color(230,230,250));            //light purple
                panel4.setBounds(70,90,600,500);
                panel4.setLayout(null);
                panel4.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));     
                panel.add(panel4);
                
                b1 = new JButton("Back");
                b1.setBounds(470,455,90,24);
                b1.setBackground(Color.black);
                b1.setForeground(Color.white);
                b1.setFont(new Font("Tahoma", Font.BOLD, 15));
                b1.addActionListener(this);
                panel4.add(b1);
                }
                
                public static void main(String[] args)
                {
                 new viewassignment().setVisible(true);
                }
                    
                public void actionPerformed(ActionEvent e) {
                   if(e.getSource() == b1){
                   setVisible(false);
                   ProjectManagmntSystem pms = new ProjectManagmntSystem("");
                   pms.setVisible(true);
         }
                }            }