
package project.managmnt.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.sql.*;

public class TeacherZone extends JFrame implements ActionListener{
    JPanel panel;
    JButton J1,J2,J3,J4,J5,J6;
    JTextField t1,t2,t3,t4,t5,t6; 
    String username;
    TeacherZone(String username){
        this.username=username;
        setTitle("Project Management System");
                setPreferredSize(new Dimension(700,550));
                pack();
                setLocationRelativeTo(null);
                setResizable(false);
                panel = new JPanel();
                panel.setBackground(new Color(70,130,180));                            //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.black, 2), " Teacher Zone ",
                TitledBorder.LEADING, TitledBorder.TOP, null, Color.white));
                
                
                JPanel panel1 = new JPanel();
                panel1.setBackground(new Color(135,206,250));
                panel1.setBounds(12,17,660,120);
                panel1.setLayout(null);                                                  //uper partition
                panel1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                panel.add(panel1);
                
                JLabel l1 = new JLabel("ID");                            
                l1.setBounds(12,5,90,25);
                l1.setFont(new Font("Times new roman", Font.BOLD, 22));
                panel1.add(l1);
                
                JLabel l2 = new JLabel("Username");                            
                l2.setBounds(12,35,150,25);
                l2.setFont(new Font("Times new roman", Font.BOLD, 22));
                panel1.add(l2);
                
                JLabel l3 = new JLabel("Name");                            
                l3.setBounds(12,65,90,25);
                l3.setFont(new Font("Times new roman", Font.BOLD, 22));
                panel1.add(l3);
                
                JLabel l4 = new JLabel("Address");                            
                l4.setBounds(12,95,150,24);
                l4.setFont(new Font("Times new roman", Font.BOLD, 22));
                panel1.add(l4);
                
                JLabel l5 = new JLabel("Mail id:");                            
                l5.setBounds(270,5,90,24);
                l5.setFont(new Font("Times new roman", Font.BOLD, 22));
                panel1.add(l5);
                
                JLabel l6 = new JLabel("Phone no.");                            
                l6.setBounds(270,35,230,24);
                l6.setFont(new Font("Times new roman", Font.BOLD, 22));
                panel1.add(l6);
                        
                JPanel panel2 = new JPanel();
                panel2.setBackground(new Color(135,206,250));
                panel2.setBounds(12,140,660,360);
                panel2.setLayout(null);                                                  //lower partition
                panel2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                panel.add(panel2);
                
                JPanel panel3 = new JPanel();
                panel3.setBackground(new Color(70,130,180));
                panel3.setBounds(10,10,250,340);
                panel3.setLayout(null);                                     //Panel for buttons in lower partition
                panel3.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1)));
                panel2.add(panel3);
                
                //**********  JTextarea   ***********//
                t1 = new JTextField();
                t1.setEditable(false);
                t1.setFont(new Font("Times New Roman", Font.BOLD, 20));     //id
                t1.setForeground(Color.black);   
                t1.setBackground(Color.white);
                t1.setBounds(120,5,120,25);
                panel1.add(t1);
                
                t2 = new JTextField(username);
                t2.setEditable(false);
                t2.setFont(new Font("Times New Roman", Font.BOLD, 20));  //username
                t2.setForeground(Color.black);   
                t2.setBackground(Color.white);
               //t2.setBackground(new Color(70,130,180));
                t2.setBounds(120,35,120,25);
                panel1.add(t2);
                
                t3 = new JTextField();
                t3.setEditable(false);
                t3.setFont(new Font("Times New Roman", Font.BOLD, 18));    //name
                t3.setForeground(Color.black);   
                t3.setBackground(Color.white);
                t3.setBounds(120,65,180,25);
                panel1.add(t3);
                
                t4 = new JTextField();
                t4.setEditable(false);                           //mail oid
                t4.setFont(new Font("Times New Roman", Font.BOLD, 16));  
                t4.setForeground(Color.black);   
                t4.setBackground(Color.white);
                t4.setBounds(370,5,220,25);
                panel1.add(t4);
                
                t5 = new JTextField();
                t5.setEditable(false);
                t5.setFont(new Font("Times New Roman", Font.BOLD, 20));         //phone no
                t5.setForeground(Color.black);   
                t5.setBackground(Color.white);
                t5.setBounds(370,35,120,25);
                panel1.add(t5);
                
                t6 = new JTextField();
                t6.setEditable(false);
                t6.setFont(new Font("Times New Roman", Font.BOLD, 18));     //address
                t6.setForeground(Color.black);   
                t6.setBackground(Color.white);
                t6.setBounds(120,94,440,24);
                panel1.add(t6);
                
                //*************   buttons    **********//
                
                J1 = new JButton("View Student Details");
                J1.setBounds(10,12,220,50);
                J1.setBackground(new Color(0,0,128));
                J1.setForeground(Color.white);
                J1.addActionListener(this);
                panel3.add(J1);
                
                
                J2 = new JButton("Upload Assignment");
                J2.setBounds(10,77,220,50);
                J2.setBackground(new Color(0,0,128));
                J2.setForeground(Color.white);
                panel3.add(J2);
                
                J3 = new JButton("View Uploaded Assignment");
                J3.setBounds(10,142,220,50);
                J3.setBackground(new Color(0,0,128));
                J3.setForeground(Color.white);
                panel3.add(J3);
               
                J4 = new JButton("Time table");
                J4.setBounds(10,207,220,50);
                J4.setBackground(new Color(0,0,128));
                J4.setForeground(Color.white);
                J4.addActionListener(this);
                panel3.add(J4);
                
                J5 = new JButton("Veiw Querry");
                J5.setBounds(10,272,220,50);
                J5.setBackground(new Color(0,0,128));
                J5.setForeground(Color.white);
                J5.addActionListener(this);
                panel3.add(J5);
                
                J6 = new JButton("LogOut");
                J6.setBounds(569,334,80,17);
                J6.setBackground(new Color(0,0,128));
                J6.setForeground(Color.white);
                J6.addActionListener(this);
                panel2.add(J6);
                
                 try{
                    Conn c = new Conn();
                    ResultSet rs = c.s.executeQuery("select * from tinfo where username = '"+username+"'");
                    if(rs.next()){
                        t1.setText(rs.getString(1));  
                        t2.setText(rs.getString(2));
                        t3.setText(rs.getString(3));  
                        t4.setText(rs.getString(4));
                        t5.setText(rs.getString(5));  
                        t6.setText(rs.getString(6));
                        
                    }
                }catch(SQLException e){ }
                
    }
    
    
    public static void main(String args[]){
            new TeacherZone("").setVisible(true);
    }

    
    public void actionPerformed(ActionEvent e) {
         if(e.getSource() == J1){
                setVisible(false);
		ViewStuDetails vsd = new ViewStuDetails();
		vsd.setVisible(true);
         }  
         if(e.getSource() == J4){
                setVisible(true);
		TeaTimeTable ttt = new TeaTimeTable();
		ttt.setVisible(true);
         }  
        if(e.getSource() == J5){
                setVisible(true);
		ContactStudent ct = new ContactStudent();
		ct.setVisible(true);
         }  
        if(e.getSource() == J6){
                setVisible(false);
		Teacherlogin tl = new Teacherlogin("");
		tl.setVisible(true);
         }  
    }
}
