package project.managmnt.system;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.*;


public class Timetable extends JFrame implements ActionListener{
    JPanel panel;
    JButton b1;
        Timetable(){
        setTitle("Project Management System");
                setPreferredSize(new Dimension(700,650));
                pack();
                setLocationRelativeTo(null);
                setResizable(false);
                
                panel = new JPanel();
                panel.setBackground(new Color(216,191,216));                            //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2), "",
                TitledBorder.LEADING, TitledBorder.TOP, null, Color.black));
                
                JPanel panel2 = new JPanel();
                panel2.setBackground(new Color(218,112,214));                            //panel for time table
                panel2.setLayout(null);
                setContentPane(panel);
                panel2.setBounds(2,17,682,49);
                panel2.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel2);
                
                JLabel l1 = new JLabel("Time  Table");                              //label for time table
                l1.setBounds(210,6,290,43);
                l1.setFont(new Font("Times new roman", Font.BOLD, 40));
                panel2.add(l1);
                
                ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/timetable.jpg"));
                Image i2 = i1.getImage().getScaledInstance(672, 452,Image.SCALE_DEFAULT);
                ImageIcon i3 = new ImageIcon(i2);
        
               JLabel l2 = new JLabel(i3);
               l2.setBounds(5,125,672,452);                        //label for first imge
               l2.setBackground(Color.white);
               panel.add(l2);  
                
                JPanel panel3 = new JPanel();
                panel3.setBackground(new Color(218,112,214));                            //panel for menubar
                panel3.setLayout(null);
                setContentPane(panel);
                panel3.setBounds(2,85,682,30);
                panel3.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel3);
                
                JPanel panel4 = new JPanel();
                panel4.setBackground(new Color(218,112,214));                            //panel for menubar
                panel4.setLayout(null);
                setContentPane(panel);
                panel4.setBounds(2,75,682,10);
                panel4.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel4);
                
                b1 = new JButton("Back");
                b1.setFont(new Font("Times new roman", Font.BOLD, 14));
                b1.setBounds(568, 543, 90, 25);              
                b1.setBackground(Color.BLACK);
                b1.setForeground(Color.WHITE);
                b1.addActionListener(this);
                panel.add(b1);
                
                JMenuBar menuBar = new JMenuBar();
                setJMenuBar(menuBar);
                menuBar.setBounds(40,39,100,20);
                panel3.add(menuBar);
                JMenu m1 = new JMenu("Branch CSE");
                m1.setForeground(Color.black);
              //  m1.setBackground(Color.black);
                m1.setBounds(52,24,290,25);
                menuBar.add(m1);
		
                JMenuItem mi1 = new JMenuItem("1st sem");
                m1.add(mi1);

                JMenuItem mi2 = new JMenuItem("2nd sem");
                m1.add(mi2);

                JMenuItem mi3 = new JMenuItem("3rd sem");
                m1.add(mi3);

                JMenuItem mi4 = new JMenuItem("4th sem");
                m1.add(mi4);
                
                mi1.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                if(ae.getSource() == mi1){                        
                setVisible(true);
                try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                 }
                }
            });
                
                
        
                mi2.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                if(ae.getSource() == mi2){                        
                setVisible(true);
                 try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                 }
                }
            });

                mi3.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                if(ae.getSource() == mi3){                        
                setVisible(true);
                 try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                   }
                  }
            });

                mi4.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                if(ae.getSource() == mi4){                        
                setVisible(true);
                  try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }
                   }
            });
               
                JMenu m2 = new JMenu("Branch ECE");
                panel3.add(menuBar);
                m2.setForeground(Color.black);
                m2.setBounds(252,24,290,25);
                menuBar.add(m2);

                JMenuItem mi5 = new JMenuItem("1st sem");
                m2.add(mi5);

                JMenuItem mi6 = new JMenuItem("2nd sem");
                m2.add(mi6);

               
                 JMenuItem mi7 = new JMenuItem("3rd sem");
                m2.add(mi7);
                
                 JMenuItem mi8 = new JMenuItem("4th sem");
                m2.add(mi8);

                mi5.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi5){                        
                        setVisible(true);
                        new Timetable1().setVisible(true);                 // new CheckPackage().setVisible(true);
                       
                    }
                    }
                });
                
                mi6.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi6){                        
                        setVisible(true);
                          try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){} 
                    }
                    }
                });

                mi7.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi7){                        
                         try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }
                    }
                });

                mi8.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi8){                        
                        setVisible(true);
                         try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }

                    }
                });

                JMenu m3 = new JMenu("Branch DE");
                m3.setForeground(Color.black);
                menuBar.add(m3);

                JMenuItem mi9 = new JMenuItem("1st sem");
                m3.add(mi9);

                JMenuItem mi10 = new JMenuItem("2nd sem");
                m3.add(mi10);
                
                JMenuItem mi11 = new JMenuItem("3rd sem");
                m3.add(mi11);
                
                JMenuItem mi12 = new JMenuItem("4th sem");
                m3.add(mi12);
                
                mi9.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi9){                        
                        setVisible(true);
                            try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}   
                    }
                    }
                });

                mi10.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi10){                        
                        setVisible(true);
                       try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }
                    }
                });

                mi11.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi11){                        
                        setVisible(true);
                         try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }
                    }
                });
                
                mi12.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi12){                        
                        setVisible(true);
                         try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }
                    }
                });


                JMenu m4 = new JMenu("Brach CE");
                m4.setForeground(Color.black);
                menuBar.add(m4);

                JMenuItem mi13 = new JMenuItem("1st sem");
                m4.add(mi13);
                
                JMenuItem mi14 = new JMenuItem("2nd sem");
                m4.add(mi14);
                
                JMenuItem mi15 = new JMenuItem("3rd sem");
                m4.add(mi15);
                
                JMenuItem mi16 = new JMenuItem("4th sem");
                m4.add(mi16);

                mi13.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                       if(ae.getSource() == mi13){                        
                        setVisible(true);
                         try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }
                    }
                });
                
                 mi14.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                       if(ae.getSource() == mi13){                        
                        setVisible(true);
                       try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }
                    }
                });
                
        
                mi15.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        if(ae.getSource() == mi15){                        
                        setVisible(true);
                        try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                    }
                    }
                });
                
        
                mi16.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                       if(ae.getSource() == mi16){                        
                        setVisible(true);
                         try{
                    new Timetable1().setVisible(true);   
                }catch(Exception e ){}
                       }
                    }
                });
                 JMenu m5 = new JMenu("UTILITY");
                m5.setForeground(Color.black);
                menuBar.add(m5);

                JMenuItem mi17 = new JMenuItem("NOTEPAD");
                m5.add(mi17);

                mi17.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                        try{
                            Runtime.getRuntime().exec("notepad.exe");
                        }catch(Exception e){ }
                    }
                });
                     }
        
        public static void main(String args[]){
            new Timetable().setVisible(true);
    }

    
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b1){
                setVisible(false);
		ProjectManagmntSystem ms = new ProjectManagmntSystem("");
		ms.setVisible(true);
         }  
    }
}


