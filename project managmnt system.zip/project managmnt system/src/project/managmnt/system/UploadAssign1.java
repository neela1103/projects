
package project.managmnt.system;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class UploadAssign1 extends JFrame implements ActionListener {
        JPanel panel;
        JButton b1,b2,b3,b4,b5,b6;
             UploadAssign1(){
                 setPreferredSize(new Dimension(360,290));
                 pack();
                setLocationRelativeTo(null);
                setResizable(false);
                panel = new JPanel();
                panel.setBackground(Color.LIGHT_GRAY);                            //full panel
                panel.setLayout(null);
                setContentPane(panel);
                panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                
                JPanel panel1= new JPanel();
                panel1.setBackground(Color.white); 
                panel1.setBounds(3,8, 340, 30); 
                panel1.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 2)));
                panel.add(panel1);
                
                JLabel l = new JLabel("Select subject from here");
                l.setBounds(40,4,190,25);
                //l.setBackground(Color.pink);
                l.setFont(new Font("Times new roman", Font.BOLD, 18));
                panel1.add(l);
                
                b1 = new JButton("AM-1");
                b1.setBackground(Color.black);
                b1.setForeground(Color.white);
                b1.setBounds(25,55,120,40);
                b1.addActionListener(this);
                panel.add(b1);
                
                b2 = new JButton("AP-1");
                b2.setBackground(Color.black);
                b2.setForeground(Color.white);
                b2.setBounds(188,55,120,40);
                b2.addActionListener(this);
                panel.add(b2);
                
                b3 = new JButton("MP");
                b3.setBackground(Color.black);
                b3.setForeground(Color.white);
                b3.setBounds(110,110,120,40);
                b3.addActionListener(this);
                panel.add(b3);
                
                b4 = new JButton("IIT");
                b4.setBackground(Color.black);
                b4.setForeground(Color.white);
                b4.setBounds(25,165,120,40);
                b4.addActionListener(this);
                panel.add(b4);
                
                b5 = new JButton("BE");
                b5.setBackground(Color.black);
                b5.setForeground(Color.white);
                b5.setBounds(188,165,120,40);
                b5.addActionListener(this);
                panel.add(b5); 
                
                b6 = new JButton("BACK");
                b6.setBackground(Color.black);
                b6.setForeground(Color.white);
                b6.setBounds(250,227,90,20);
                b6.addActionListener(this);
                panel.add(b6); 
                
                
    }
    
    public static void main(String args[]){
        new UploadAssign1().setVisible(true);
    }

    
    public void actionPerformed(ActionEvent e) {
         if(e.getSource() == b1){
                setVisible(false);
		UploadAssign2 ua2 = new UploadAssign2();
		ua2.setVisible(true);
            }
          if(e.getSource() == b2){
                setVisible(false);
		UploadAssign2 ua2 = new UploadAssign2();
		ua2.setVisible(true);
            }
           if(e.getSource() == b3){
                setVisible(false);
		UploadAssign2 ua2 = new UploadAssign2();
		ua2.setVisible(true);
                
            } if(e.getSource() == b4){
                setVisible(false);
		UploadAssign2 ua2 = new UploadAssign2();
		ua2.setVisible(true);
            }
             if(e.getSource() == b5){
                setVisible(false);
		UploadAssign2 ua2 = new UploadAssign2();
		ua2.setVisible(true);
            }
            if(e.getSource() == b6){
                setVisible(false);
		UploadAssign ua = new UploadAssign();
		ua.setVisible(true);
            }
    }
}
