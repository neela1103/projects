
package project.managmnt.system;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.*;

public class ProjectManagmntSystem extends JFrame implements ActionListener{
    private JPanel panel;
    private JButton b1,b2,b3,b4,b5,b6,b7; 
    private JTextField t1;
    String name; 
    
    ProjectManagmntSystem(String name){
        this.name= name;
        setTitle("Project Management System");
        setPreferredSize(new Dimension(1000,650));
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
     
        panel = new JPanel();
	panel.setBackground(new Color(128,0,128));
	setContentPane(panel);
        panel.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 5), "Student Profile",
			TitledBorder.LEADING, TitledBorder.TOP, null, Color.white));
        panel.setLayout(null);
        
        JPanel panel2 = new JPanel();
        panel2.setBackground(new Color(216,191,216));  //for student image
        panel2.setBounds(850,20,120,103);
        panel.add(panel2);
	
            t1 = new JTextField("WELCOME   "+name);
            t1.setEditable(false);
            t1.setFont(new Font("Times New Roman", Font.BOLD, 24));
            t1.setForeground(new Color(128,0,128));
            t1.setBounds(20, 30, 590, 30);
            panel.add(t1);
            
        JPanel panel4 = new JPanel();
        panel4.setBackground(new Color(216,191,216));     //for buttons
        panel4.setBounds(20,80,300,500);
        panel4.setLayout(null);
        panel.add(panel4);
       
        b1 = new JButton("Student Details");
        b1.setBounds(20,20,250,40);
        b1.setBackground(new Color(128,0,128));
        b1.setForeground(Color.white);
	b1.setFont(new Font("Tahoma", Font.BOLD, 20));
        b1.addActionListener(this);
        panel4.add(b1);
        
        b2 = new JButton("View Syllabus");
        b2.setBounds(20,100,250,40);
        b2.setBackground(new Color(128,0,128));
        b2.setForeground(Color.white);
	b2.setFont(new Font("Tahoma", Font.BOLD, 20));
        b2.addActionListener(this);
        panel4.add(b2);
        
        b3 = new JButton("View Assigment");
        b3.setBounds(20,180,250,40);
        b3.setBackground(new Color(128,0,128));
        b3.setForeground(Color.white);
	b3.setFont(new Font("Tahoma", Font.BOLD, 20));
        b3.addActionListener(this);
        panel4.add(b3);
        
        b4 = new JButton("Upload Assigment");
        b4.setBounds(20,260,250,40);
        b4.setBackground(new Color(128,0,128));
        b4.setForeground(Color.white);
	b4.setFont(new Font("Tahoma", Font.BOLD, 20));
        b4.addActionListener(this);
        panel4.add(b4);
        
        b5 = new JButton("Time Table");
         b5.setBounds(20,340,250,40);
        b5.setBackground(new Color(128,0,128));
        b5.setForeground(Color.WHITE);
	b5.setFont(new Font("Tahoma", Font.BOLD, 20));
        b5.addActionListener(this);
        panel4.add(b5);
        
        b6 = new JButton("Contact teacher");
        b6.setBounds(20,420,250,40);
        b6.setBackground(new Color(128,0,128));
        b6.setForeground(Color.WHITE);
	b6.setFont(new Font("Tahoma", Font.BOLD, 20));
        b6.addActionListener(this);
        panel4.add(b6);
        
         b7 = new JButton("Logout");
        b7.setBounds(850,570,100,20);
        b7.setBackground(new Color(216,191,216));
        b7.setForeground(Color.black);
	b7.setFont(new Font("Tahoma", Font.BOLD, 15));
        b7.addActionListener(this);
        panel.add(b7);
	}

    public static void main(String[] args) {
      new ProjectManagmntSystem("").setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b1){
                setVisible(false);                
		Studentdetails1 sd = new Studentdetails1(name);
		sd.setVisible(true);
         }  
        
        
        if(e.getSource() == b2){
                setVisible(false);
		viewsyllabus1 sp = new viewsyllabus1();
		sp.setVisible(true);
            }  
            if(e.getSource() == b3){
                setVisible(false);
		viewassignment va = new viewassignment();
		va.setVisible(true);
            }
             if(e.getSource() == b4){
                setVisible(false);
		UploadAssign ua = new UploadAssign();
		ua.setVisible(true);
         }  /*
        if(e.getSource() == b2){
                setVisible(false);
		SignUp1 ss = new SignUp1();
		ss.setVisible(true);
            }   
            if(e.getSource() == b3){
                setVisible(false);
		Forgetpassword forgot = new Forgetpassword();
		forgot.setVisible(true);
            }*/
            
                if(e.getSource() == b5){
                setVisible(false);
		Timetable tt = new Timetable();
		tt.setVisible(true);
         }  
             if(e.getSource() == b6){
                setVisible(true);
		ContactTeacher ct = new ContactTeacher();
		ct.setVisible(true);
         }  
             if(e.getSource() == b7){
                setVisible(false);
		login l = new login();
		l.setVisible(true);
         }  
    }
}
