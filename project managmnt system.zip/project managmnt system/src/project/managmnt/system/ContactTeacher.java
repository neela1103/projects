
package project.managmnt.system;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.net.*;
import java.io.*;
import static project.managmnt.system.ContactStudent.a1;

public class ContactTeacher extends JFrame implements ActionListener{
    JPanel panel;
    JTextField t1;
    JButton j1;
    static ServerSocket skt;
    static Socket s;
    static JTextArea a1;
    static DataInputStream din;
    static DataOutputStream dout;
    //static String msginput;
    
    
    ContactTeacher(){
        setTitle("Student side");
    
            setBounds(780,190,350,460);
            setResizable(false);
            panel = new JPanel();
            panel.setBackground(Color.black);
            setContentPane(panel);
            panel.setBorder(new TitledBorder(new LineBorder(Color.white, 3)));
            panel.setLayout(null);
            
            JPanel panel1 = new JPanel();
            panel1.setBounds(5,5,326,40);
            panel1.setBackground(Color.pink);
            panel1.setLayout(null);
            panel.add(panel1);
            
            a1 = new JTextArea();
            a1.setBounds(5,47,326,340);
            a1.setBackground(Color.pink);
            a1.setFont(new Font("Aial",Font.BOLD, 20));
            a1.setLineWrap(true);
            a1.setWrapStyleWord(true);
            panel.add(a1);
            
            
            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/3.png"));
            Image i2 = i1.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
                
            JLabel l1 = new JLabel(i3);
            l1.setBounds(6,6, 30, 30);
            panel1.add(l1);
            
            l1.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent ae){
            System.exit(0);
             }
         });
            
             ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("project/managmnt/system/icons/Login.jpg"));
            Image i5 = i4.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
            ImageIcon i6 = new ImageIcon(i5);
                
            JLabel l2 = new JLabel(i6);
            l2.setBounds(46,6, 30, 30);
            panel1.add(l2);
            
            t1= new JTextField();
            t1.setBounds(4, 390, 257, 30);
            t1.setFont(new Font("Aial",Font.BOLD, 20));
            panel.add(t1);
            
            j1 = new JButton("send");
            j1.setBounds(262, 390, 70, 30);
            j1.setBackground(Color.pink);
            j1.setForeground(Color.black);
            j1.addActionListener(this);
            panel.add(j1);
            
    }
     /**
     *
     * @param ae
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
       try{
       String out = t1.getText();
       a1.setText(a1.getText()+"\n\t\t"+out);
       t1.setText("");
       dout.writeUTF(out);
       }catch(Exception e){e.printStackTrace();}

    }
    
    public static void main(String args[]){
         ContactTeacher ct = new ContactTeacher();
    ct.setVisible(true);
          String msginput = "";
        try{
        skt = new ServerSocket(6001);
        s = skt.accept();
        din = new DataInputStream(s.getInputStream());
        dout = new DataOutputStream(s.getOutputStream());
        while(true){
        a1.setText(a1.getText()+"\n"+msginput);
        msginput = din.readUTF();
       // skt.close();
       // s.close();
        }
        }catch(Exception ae){ae.printStackTrace();}
   
    }

   
}